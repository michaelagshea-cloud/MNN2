# MNN5 current uploaded evidence review

Generated: 2026-05-31

## Bottom line

The newest files are enough to treat CP022975.1 as the active/current MNN5 coordinate system for this uploaded package. The MNN5 edit manifest states that MNN5/YJL186W is on chromosome X accession CP022975.1, plus strand, native interval 92610-94370, replaced with `MNN5_ISC1gamma_opt1_optimized_CDS_1434bp_CAI086_stopTAA`, edited feature 92610-94043, with exact insertion and transcript-orientation checks marked True.

This remains an in-silico edited genome depiction, not wet-lab validation, not gRNA/off-target screening, and not expression/function evidence.

## Key MNN5 evidence present

- MNN5 edit manifest row, filtered into `reports/MNN5_triple_lock_edit_manifest.csv`.
- MNN5 orientation/translation QC row, filtered into `reports/MNN5_orientation_translation_QC.csv`.
- MNN5 edited GFF3 feature, filtered into `reports/MNN5_edited_features.gff3`.
- MNN5 optimized CDS in transcript orientation and genomic insert orientation.
- MNN5 edited locus cassette with 500 bp CP022 arms.
- MNN5 active modified primer panel and local in-silico PCR outputs.

## Remaining needs before publication-style claims

1. Wet-lab DNA validation: junction PCR/Sanger or amplicon sequencing across the MNN5 edited locus plus native-ORF-loss assay.
2. Formal genome-wide/off-target review for any gRNA design.
3. Expression/function evidence if claiming RNA/protein/EV phenotype.
4. Decide whether the current MNN5 junction primer set is adequate, because the local PCR interpretation flags left and right junction assays as review/caution rather than standalone integration proof.
