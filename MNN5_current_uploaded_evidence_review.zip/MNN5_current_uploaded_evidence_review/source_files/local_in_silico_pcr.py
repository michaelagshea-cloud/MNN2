#!/usr/bin/env python3
"""
local_in_silico_pcr.py
Exact-match in-silico PCR for the frozen CEN.PK113-7D modified primer panel.
No external packages required.

Usage:
  python3 scripts/local_in_silico_pcr.py references/CENPK113_CP022_unedited_plus_edited_validation_reference.fasta.gz data/primers/FINAL_ACTIVE_PRIMER_PANEL_MODIFIED_ONLY.csv results/local_pcr
"""
import csv, gzip, re, sys, textwrap
from pathlib import Path

def rc(seq):
    return seq.upper().translate(str.maketrans('ACGTN','TGCAN'))[::-1]

def clean(seq):
    return re.sub(r'[^ACGTNacgtn]','',str(seq)).upper()

def read_text(path):
    path=Path(path)
    if str(path).endswith('.gz'):
        with gzip.open(path,'rt') as f: return f.read()
    return path.read_text()

def parse_fasta(path):
    text=read_text(path)
    records=[]; h=None; seq=[]
    for line in text.splitlines():
        line=line.strip()
        if not line: continue
        if line.startswith('>'):
            if h is not None: records.append((h,''.join(seq).upper()))
            h=line[1:].strip(); seq=[]
        else:
            seq.append(clean(line))
    if h is not None: records.append((h,''.join(seq).upper()))
    return records

def fasta_rec(h,s):
    return f'>{h}\n'+'\n'.join(textwrap.wrap(s,80))+'\n'

def main():
    if len(sys.argv)<4:
        print(__doc__); sys.exit(1)
    ref_path, primer_csv, out_dir = sys.argv[1:4]
    out=Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    refs=parse_fasta(ref_path)
    rows=list(csv.DictReader(open(primer_csv)))
    max_product=5000
    product_rows=[]; binding_rows=[]; amp_records=[]
    for row in rows:
        locus=row['locus']; assay=row['assay']
        fseq=clean(row['forward_sequence_5to3']); rseq=clean(row['reverse_sequence_5to3'])
        expected=int(row['expected_product_bp'])
        products=[]
        for h,seq in refs:
            # individual exact matches
            for role,name,p in [('forward',row['forward_primer_name'],fseq),('reverse',row['reverse_primer_name'],rseq)]:
                for strand,pat in [('+',p),('-',rc(p))]:
                    start=0
                    while True:
                        i=seq.find(pat,start)
                        if i<0: break
                        binding_rows.append({'locus':locus,'assay':assay,'primer_name':name,'role':role,'primer_sequence_5to3':p,'template':h,'strand_match_on_reference':strand,'start_1based':i+1,'end_1based':i+len(pat)})
                        start=i+1
            # PCR products: forward on plus, reverse-complement downstream on plus
            fpos=[m.start()+1 for m in re.finditer(re.escape(fseq),seq)]
            rpos=[m.start()+1 for m in re.finditer(re.escape(rc(rseq)),seq)]
            for fs in fpos:
                for rs in rpos:
                    if rs>fs:
                        plen=rs+len(rseq)-fs
                        if plen<=max_product:
                            pseq=seq[fs-1:rs+len(rseq)-1]
                            products.append(('F_plus_R_down',h,fs,rs+len(rseq)-1,plen,pseq))
            # reverse-oriented product
            rplus=[m.start()+1 for m in re.finditer(re.escape(rseq),seq)]
            fdown=[m.start()+1 for m in re.finditer(re.escape(rc(fseq)),seq)]
            for rs in rplus:
                for fs in fdown:
                    if fs>rs:
                        plen=fs+len(fseq)-rs
                        if plen<=max_product:
                            pseq=rc(seq[rs-1:fs+len(fseq)-1])
                            products.append(('R_plus_F_down_reverse_oriented',h,rs,fs+len(fseq)-1,plen,pseq))
        if not products:
            product_rows.append({'locus':locus,'assay':assay,'sequence_id':row['sequence_id'],'expected_product_bp':expected,'observed_product_bp':'','matches_expected_bp':'NO_PRODUCT_FOUND','template':'','start_1based':'','end_1based':'','orientation':'','interpretation':'No exact product found in supplied reference.'})
        else:
            for idx,(orient,h,start,end,plen,pseq) in enumerate(products,1):
                expected_match='YES' if plen==expected else 'NO'
                if expected_match=='YES' and 'EDITED_TRIPLE_LOCK_FULL_GENOME' in h:
                    interp='Expected-size product in edited full genome.'
                elif expected_match=='YES' and 'UNEDITED' in h:
                    interp='Expected-size product in unedited/native reference.'
                elif expected_match=='YES' and 'DONOR' in h:
                    interp='Expected-size product in donor/native small sequence; review donor-only risk for junction assays.'
                elif expected_match=='YES':
                    interp='Expected-size product in supporting reference sequence.'
                else:
                    interp='Off-size product; review specificity.'
                product_rows.append({'locus':locus,'assay':assay,'sequence_id':row['sequence_id'],'expected_product_bp':expected,'observed_product_bp':plen,'matches_expected_bp':expected_match,'template':h,'start_1based':start,'end_1based':end,'orientation':orient,'interpretation':interp})
                amp_records.append((f"{locus}|{assay}|{row['sequence_id']}|product{idx}|{plen}bp|{h[:80]}",pseq))
    # summary
    with open(out/'local_in_silico_PCR_products.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(product_rows[0].keys())); w.writeheader(); w.writerows(product_rows)
    with open(out/'primer_exact_binding_sites.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(binding_rows[0].keys())); w.writeheader(); w.writerows(binding_rows)
    with open(out/'local_in_silico_amplicons.fasta','w') as f:
        for h,s in amp_records: f.write(fasta_rec(h,s))
    summary=[]
    for row in rows:
        key=(row['locus'],row['assay'],row['sequence_id'],str(row['expected_product_bp']))
        subset=[p for p in product_rows if p['locus']==row['locus'] and p['assay']==row['assay'] and p['sequence_id']==row['sequence_id']]
        exp=[p for p in subset if p['matches_expected_bp']=='YES']
        summary.append({'locus':row['locus'],'assay':row['assay'],'sequence_id':row['sequence_id'],'expected_product_bp':row['expected_product_bp'],'expected_size_product_count':len(exp),'all_product_count':len([p for p in subset if p['observed_product_bp']!='']),'expected_size_template_contexts':' | '.join(sorted(set([p['template'].split('|')[0] for p in exp]))),'recommended_review':'PASS_EXPECTED_SIZE_FOUND' if exp else 'REVIEW_NO_EXPECTED_PRODUCT'})
    with open(out/'local_in_silico_PCR_summary.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0].keys())); w.writeheader(); w.writerows(summary)
    print('Wrote results to',out)
if __name__=='__main__': main()
