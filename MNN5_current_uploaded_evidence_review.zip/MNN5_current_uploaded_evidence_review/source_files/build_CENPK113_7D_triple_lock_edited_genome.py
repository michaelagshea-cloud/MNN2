#!/usr/bin/env python3
"""
Build an in-silico edited CEN.PK113-7D genome from the uploaded CP022-coordinate
locus package and optimized CDS candidates.

What this script does:
1. Uses the CEN.PK113-7D CP022 reference genome from ncbi_dataset(1).zip.
2. Uses target coordinates from CENPK113_7D_extracted_loci_and_homology_arms(1).zip.
3. Replaces three native ORF intervals:
   - MNN2/YBR015C -> MNN2_ISC1beta optimized CDS
   - OCH1/YGL038C -> OCH1_ISC1alpha optimized CDS
   - MNN5/YJL186W -> MNN5_ISC1gamma optimized CDS
4. Leaves the native ISC1/YER019W locus unchanged because no separate validated
   standalone ISC1 optimized CDS was present in the uploaded optimized-CDS package.
5. Writes a full edited genome FASTA, edited CDS FASTA, 500 bp-arm edited locus
   cassette FASTA, GFF3 feature file, and CSV audit tables.

Important limitation:
This is an in-silico sequence depiction/assembly. It is not wet-lab validation,
not gRNA design, not off-target screening, and not a final HDR donor design.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import os
import re
import textwrap
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

BASE_DIR = Path(__file__).resolve().parent

REFERENCE_ZIP = BASE_DIR / "ncbi_dataset(1).zip"
LOCI_ZIP = BASE_DIR / "CENPK113_7D_extracted_loci_and_homology_arms(1).zip"
OPTIMIZED_CDS_ZIP = BASE_DIR / "optimized_CDS_restart_fasta_package(1).zip"
PROTEIN_COMPARISON_ZIP = BASE_DIR / "ISC1_candidate_vs_CENPK_native_protein_comparison(1).zip"

REFERENCE_FASTA_IN_ZIP = "ncbi_dataset/data/GCA_002885995.1/GCA_002885995.1_ASM288599v1_genomic.fna"
COORDINATES_CSV_IN_ZIP = "CENPK113_target_loci_coordinates.csv"
NATIVE_LOCI_FASTA_IN_ZIP = "CENPK113_target_loci_genomic_forward.fasta"
HOMOLOGY_ARMS_500_FASTA_IN_ZIP = "CENPK113_500bp_left_right_homology_arms_genomic.fasta"
OPTIMIZED_CDS_FASTA_IN_ZIP = "optimized_CDS_candidates_MNN2_OCH1_MNN5_combined.fasta"
OPTIMIZED_CDS_MANIFEST_IN_ZIP = "optimized_CDS_candidates_manifest.csv"
ISC1_PAYLOAD_COMPARISON_CSV_IN_ZIP = "ISC1_payload_region_vs_CENPK_native_ISC1_protein_comparison.csv"

OUT_DIR = BASE_DIR / "CENPK113_7D_triple_lock_edited_genome_package"
OUT_DIR.mkdir(exist_ok=True)

DNA_TRANS = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def clean_seq(seq: str) -> str:
    return re.sub(r"[^A-Za-z]", "", seq).upper()


def revcomp(seq: str) -> str:
    return clean_seq(seq).translate(DNA_TRANS)[::-1].upper()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def wrap(seq: str, width: int = 80) -> str:
    return "\n".join(textwrap.wrap(seq, width))


def parse_fasta_text(text: str) -> Dict[str, Tuple[str, str]]:
    """Return {record_id: (full_header_without_>, sequence)}."""
    records: Dict[str, Tuple[str, str]] = {}
    header = None
    chunks: List[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if header is not None:
                record_id = header.split()[0].split("|")[0]
                records[record_id] = (header, clean_seq("".join(chunks)))
            header = line[1:].strip()
            chunks = []
        else:
            chunks.append(line)
    if header is not None:
        record_id = header.split()[0].split("|")[0]
        records[record_id] = (header, clean_seq("".join(chunks)))
    return records


def read_zip_text(zip_path: Path, member: str) -> str:
    with zipfile.ZipFile(zip_path) as zf:
        return zf.read(member).decode("utf-8", errors="replace")


def read_csv_from_zip(zip_path: Path, member: str) -> List[dict]:
    text = read_zip_text(zip_path, member)
    return list(csv.DictReader(io.StringIO(text)))


def read_reference_fasta_from_zip(zip_path: Path, member: str) -> Dict[str, dict]:
    text = read_zip_text(zip_path, member)
    records_raw = parse_fasta_text(text)
    records: Dict[str, dict] = {}
    for rid, (header, seq) in records_raw.items():
        accession = rid
        records[accession] = {"header": header, "seq": seq}
    return records


@dataclass(frozen=True)
class EditSpec:
    target_gene: str
    systematic_name: str
    chromosome: str
    accession: str
    strand: str
    start: int
    end: int
    native_len: int
    replacement_record_id: str | None
    replacement_seq_transcript: str | None
    replacement_len: int | None
    action: str


def load_edit_specs() -> List[EditSpec]:
    coord_rows = read_csv_from_zip(LOCI_ZIP, COORDINATES_CSV_IN_ZIP)
    cds_text = read_zip_text(OPTIMIZED_CDS_ZIP, OPTIMIZED_CDS_FASTA_IN_ZIP)
    cds_records = parse_fasta_text(cds_text)

    replacement_for_gene = {
        "MNN2": "MNN2_ISC1beta_opt1_optimized_CDS_1422bp_CAI086_stopTAG",
        "OCH1": "OCH1_ISC1alpha_opt1_optimized_CDS_1434bp_CAI086_stopTGA",
        "MNN5": "MNN5_ISC1gamma_opt1_optimized_CDS_1434bp_CAI086_stopTAA",
        # No separate standalone ISC1 optimized CDS was present; preserve native ISC1.
        "ISC1": None,
    }

    specs: List[EditSpec] = []
    for row in coord_rows:
        gene = row["target_gene"]
        replacement_id = replacement_for_gene.get(gene)
        repl_seq = cds_records[replacement_id][1] if replacement_id else None
        action = "REPLACE_NATIVE_ORF_WITH_OPTIMIZED_CDS" if replacement_id else "PRESERVE_NATIVE_LOCUS_NO_STANDALONE_OPTIMIZED_CDS_UPLOADED"
        specs.append(
            EditSpec(
                target_gene=gene,
                systematic_name=row["systematic_name"],
                chromosome=row["chromosome"],
                accession=row["chromosome_accession"],
                strand=row["strand"],
                start=int(row["start_1based"]),
                end=int(row["end_1based"]),
                native_len=int(row["length_bp"]),
                replacement_record_id=replacement_id,
                replacement_seq_transcript=repl_seq,
                replacement_len=len(repl_seq) if repl_seq else None,
                action=action,
            )
        )
    return specs


def interval(seq: str, start_1: int, end_1: int) -> str:
    return seq[start_1 - 1 : end_1]


def apply_edits(reference_records: Dict[str, dict], specs: List[EditSpec]) -> Tuple[Dict[str, dict], List[dict]]:
    edited_records = {acc: {"header": rec["header"], "seq": rec["seq"]} for acc, rec in reference_records.items()}
    audit_rows: List[dict] = []

    # Verify no overlapping edits per chromosome among replacement specs.
    repl_specs = [s for s in specs if s.replacement_record_id]
    by_acc: Dict[str, List[EditSpec]] = {}
    for s in repl_specs:
        by_acc.setdefault(s.accession, []).append(s)
    for acc, items in by_acc.items():
        items_sorted = sorted(items, key=lambda x: x.start)
        for a, b in zip(items_sorted, items_sorted[1:]):
            if a.end >= b.start:
                raise ValueError(f"Overlapping edits on {acc}: {a.target_gene} and {b.target_gene}")

    # Apply from right to left per chromosome to avoid coordinate shifts.
    for acc, items in by_acc.items():
        if acc not in edited_records:
            raise KeyError(f"Reference accession not found: {acc}")
        seq = edited_records[acc]["seq"]
        original_len = len(seq)
        for s in sorted(items, key=lambda x: x.start, reverse=True):
            if s.replacement_seq_transcript is None:
                continue
            native = interval(seq, s.start, s.end)
            if len(native) != s.native_len:
                raise ValueError(f"Native interval length mismatch for {s.target_gene}")
            replacement_genomic = s.replacement_seq_transcript if s.strand == "plus" else revcomp(s.replacement_seq_transcript)
            seq = seq[: s.start - 1] + replacement_genomic + seq[s.end :]
        edited_records[acc]["seq"] = seq
        edited_records[acc]["header"] = edited_records[acc]["header"] + " | in_silico_edited_triple_lock"

    # Build audit after edits.
    for s in specs:
        ref_seq = reference_records[s.accession]["seq"]
        native_genomic = interval(ref_seq, s.start, s.end)
        native_transcript = native_genomic if s.strand == "plus" else revcomp(native_genomic)
        row = {
            "target_gene": s.target_gene,
            "systematic_name": s.systematic_name,
            "chromosome": s.chromosome,
            "chromosome_accession": s.accession,
            "strand": s.strand,
            "original_start_1based": s.start,
            "original_end_1based": s.end,
            "native_length_bp": s.native_len,
            "native_genomic_sha256": sha256_text(native_genomic),
            "native_transcript_sha256": sha256_text(native_transcript),
            "action": s.action,
            "replacement_record_id": s.replacement_record_id or "",
            "replacement_length_bp_transcript_orientation": s.replacement_len or "",
            "replacement_transcript_sha256": sha256_text(s.replacement_seq_transcript) if s.replacement_seq_transcript else "",
            "length_delta_bp": (s.replacement_len - s.native_len) if s.replacement_len else 0,
            "edited_feature_start_1based": s.start,
            "edited_feature_end_1based": (s.start + s.replacement_len - 1) if s.replacement_len else s.end,
        }
        if s.replacement_seq_transcript:
            edited_seq = edited_records[s.accession]["seq"]
            edited_feature = interval(edited_seq, s.start, s.start + s.replacement_len - 1)
            expected_genomic = s.replacement_seq_transcript if s.strand == "plus" else revcomp(s.replacement_seq_transcript)
            row["edited_insert_genomic_sha256"] = sha256_text(edited_feature)
            row["edited_insert_transcript_sha256"] = sha256_text(edited_feature if s.strand == "plus" else revcomp(edited_feature))
            row["replacement_inserted_exactly"] = str(edited_feature == expected_genomic)
            row["transcript_orientation_matches_candidate"] = str((edited_feature if s.strand == "plus" else revcomp(edited_feature)) == s.replacement_seq_transcript)
        else:
            row["edited_insert_genomic_sha256"] = ""
            row["edited_insert_transcript_sha256"] = ""
            row["replacement_inserted_exactly"] = "NATIVE_PRESERVED"
            row["transcript_orientation_matches_candidate"] = "NATIVE_PRESERVED"
        audit_rows.append(row)
    return edited_records, audit_rows


def write_fasta(path: Path, records: Iterable[Tuple[str, str]], width: int = 80) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for header, seq in records:
            f.write(f">{header}\n")
            f.write(wrap(seq, width) + "\n")


def write_fasta_gz(path: Path, records: Iterable[Tuple[str, str]], width: int = 80) -> None:
    with gzip.open(path, "wt", encoding="utf-8") as f:
        for header, seq in records:
            f.write(f">{header}\n")
            f.write(wrap(seq, width) + "\n")


def load_500bp_arms() -> Dict[Tuple[str, str], str]:
    text = read_zip_text(LOCI_ZIP, HOMOLOGY_ARMS_500_FASTA_IN_ZIP)
    records = parse_fasta_text(text)
    arms: Dict[Tuple[str, str], str] = {}
    for rid, (header, seq) in records.items():
        gene = rid.split("_")[0]
        arm_type = "left" if "_left500_" in rid else "right" if "_right500_" in rid else "unknown"
        arms[(gene, arm_type)] = seq
    return arms


def make_outputs(reference_records: Dict[str, dict], edited_records: Dict[str, dict], specs: List[EditSpec], audit_rows: List[dict]) -> None:
    # Full edited genome FASTA.
    ordered_accessions = list(reference_records.keys())
    fasta_records = []
    for acc in ordered_accessions:
        rec = edited_records[acc]
        seq = rec["seq"]
        status = "edited" if any(s.accession == acc and s.replacement_record_id for s in specs) else "unchanged"
        header = f"{rec['header']} | status={status} | length={len(seq)}"
        fasta_records.append((header, seq))
    write_fasta_gz(OUT_DIR / "CENPK113_7D_triple_lock_edited_genome.fasta.gz", fasta_records)

    # Edited chromosomes only, uncompressed for easier inspection.
    edited_chr_records = []
    for s in specs:
        if s.replacement_record_id:
            acc = s.accession
            rec = edited_records[acc]
            edited_chr_records.append((f"{rec['header']} | edited_target={s.target_gene} | length={len(rec['seq'])}", rec["seq"]))
    # Deduplicate chromosome records.
    seen = set()
    unique_edited_chr_records = []
    for header, seq in edited_chr_records:
        acc = header.split()[0]
        if acc not in seen:
            seen.add(acc)
            unique_edited_chr_records.append((header, seq))
    write_fasta(OUT_DIR / "edited_chromosomes_II_VII_X.fasta", unique_edited_chr_records)

    # Replacement CDS FASTA in transcript orientation and inserted genomic orientation.
    cds_records_transcript = []
    cds_records_genomic = []
    for s in specs:
        if not s.replacement_seq_transcript:
            continue
        cds_records_transcript.append((
            f"{s.replacement_record_id}|target={s.target_gene}|systematic={s.systematic_name}|strand={s.strand}|orientation=transcript|length={s.replacement_len}",
            s.replacement_seq_transcript,
        ))
        genomic_seq = s.replacement_seq_transcript if s.strand == "plus" else revcomp(s.replacement_seq_transcript)
        cds_records_genomic.append((
            f"{s.replacement_record_id}|target={s.target_gene}|systematic={s.systematic_name}|strand={s.strand}|orientation=genomic_forward_inserted|length={len(genomic_seq)}",
            genomic_seq,
        ))
    write_fasta(OUT_DIR / "optimized_replacement_CDS_transcript_orientation.fasta", cds_records_transcript)
    write_fasta(OUT_DIR / "optimized_replacement_CDS_genomic_insert_orientation.fasta", cds_records_genomic)

    # Edited locus cassettes with 500 bp CP022 arms (depiction, not final donor validation).
    arms = load_500bp_arms()
    cassette_records = []
    cassette_rows = []
    for s in specs:
        if not s.replacement_seq_transcript:
            continue
        left = arms.get((s.target_gene, "left"))
        right = arms.get((s.target_gene, "right"))
        if left is None or right is None:
            raise ValueError(f"Missing 500 bp arms for {s.target_gene}")
        insert_genomic = s.replacement_seq_transcript if s.strand == "plus" else revcomp(s.replacement_seq_transcript)
        cassette = left + insert_genomic + right
        cassette_records.append((
            f"{s.target_gene}_{s.systematic_name}_edited_locus_500bp_left_arm_plus_replacement_plus_500bp_right_arm|CP022={s.accession}|original_interval={s.start}-{s.end}|strand={s.strand}|cassette_length={len(cassette)}|not_final_HDR_donor",
            cassette,
        ))
        cassette_rows.append({
            "target_gene": s.target_gene,
            "systematic_name": s.systematic_name,
            "chromosome_accession": s.accession,
            "original_interval_1based": f"{s.start}-{s.end}",
            "strand": s.strand,
            "left_arm_bp": len(left),
            "replacement_bp_genomic_orientation": len(insert_genomic),
            "right_arm_bp": len(right),
            "cassette_length_bp": len(cassette),
            "cassette_sha256": sha256_text(cassette),
            "status": "IN_SILICO_EDITED_LOCUS_DEPICTION_NOT_FINAL_HDR_DONOR",
        })
    write_fasta(OUT_DIR / "edited_locus_cassettes_with_500bp_CP022_arms_genomic_orientation.fasta", cassette_records)

    # CSV audit manifest.
    audit_path = OUT_DIR / "CENPK113_7D_triple_lock_edit_manifest.csv"
    with open(audit_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(audit_rows[0].keys()))
        writer.writeheader()
        writer.writerows(audit_rows)

    cassette_path = OUT_DIR / "edited_locus_cassette_manifest.csv"
    with open(cassette_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(cassette_rows[0].keys()))
        writer.writeheader()
        writer.writerows(cassette_rows)

    # GFF3 in edited chromosome coordinates.
    gff_path = OUT_DIR / "CENPK113_7D_triple_lock_edited_features.gff3"
    with open(gff_path, "w", encoding="utf-8") as f:
        f.write("##gff-version 3\n")
        f.write("# Coordinates below are edited-genome coordinates for the replacement features.\n")
        for s in specs:
            if s.replacement_seq_transcript:
                start = s.start
                end = s.start + s.replacement_len - 1
                attrs = {
                    "ID": f"edited_{s.systematic_name}_{s.target_gene}",
                    "Name": f"{s.target_gene}_{s.replacement_record_id}",
                    "original_interval": f"{s.accession}:{s.start}-{s.end}",
                    "replacement_record": s.replacement_record_id,
                    "length_delta_bp": str(s.replacement_len - s.native_len),
                    "note": "native_ORF_replaced_with_uploaded_optimized_CDS_candidate_in_silico",
                }
                attr_text = ";".join(f"{k}={str(v).replace(' ', '_')}" for k, v in attrs.items())
                strand_symbol = "+" if s.strand == "plus" else "-"
                f.write(f"{s.accession}\tuploaded_in_silico_assembly\tgene\t{start}\t{end}\t.\t{strand_symbol}\t.\t{attr_text}\n")
            else:
                attrs = {
                    "ID": f"native_{s.systematic_name}_{s.target_gene}",
                    "Name": f"{s.target_gene}_native_preserved",
                    "note": "native_locus_preserved_no_standalone_optimized_CDS_uploaded",
                }
                attr_text = ";".join(f"{k}={str(v).replace(' ', '_')}" for k, v in attrs.items())
                strand_symbol = "+" if s.strand == "plus" else "-"
                f.write(f"{s.accession}\tuploaded_in_silico_assembly\tgene\t{s.start}\t{s.end}\t.\t{strand_symbol}\t.\t{attr_text}\n")

    # Protein comparison copied into package for provenance, if available.
    try:
        comp_rows = read_csv_from_zip(PROTEIN_COMPARISON_ZIP, ISC1_PAYLOAD_COMPARISON_CSV_IN_ZIP)
        with open(OUT_DIR / "ISC1_payload_region_protein_comparison_from_upload.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(comp_rows[0].keys()))
            writer.writeheader()
            writer.writerows(comp_rows)
    except Exception as e:
        with open(OUT_DIR / "ISC1_payload_region_protein_comparison_from_upload_README.txt", "w", encoding="utf-8") as f:
            f.write(f"Protein comparison file was not copied: {e}\n")

    # Whole-output checksum report and summary.
    checksum_rows = []
    for path in sorted(OUT_DIR.iterdir()):
        if path.is_file():
            data = path.read_bytes()
            checksum_rows.append({"file": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    with open(OUT_DIR / "package_file_checksums.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["file", "bytes", "sha256"])
        writer.writeheader()
        writer.writerows(checksum_rows)

    # Human-readable depiction/README.
    total_ref = sum(len(r["seq"]) for r in reference_records.values())
    total_edit = sum(len(r["seq"]) for r in edited_records.values())
    replaced = [r for r in audit_rows if r["action"] == "REPLACE_NATIVE_ORF_WITH_OPTIMIZED_CDS"]
    preserved = [r for r in audit_rows if r["action"] != "REPLACE_NATIVE_ORF_WITH_OPTIMIZED_CDS"]
    readme = f"""# CEN.PK113-7D in-silico Triple-Lock edited genome depiction

Reference used: CEN.PK113-7D GCA_002885995.1 / ASM288599v1 CP022 genome from `ncbi_dataset(1).zip`.

Active coordinate rule: CP022 coordinates from `CENPK113_target_loci_coordinates.csv` were used. Older CM001/GCA_000269885.1 coordinates were not used as edit coordinates.

Edits applied:
- MNN2 / YBR015C on chromosome II ({replaced[0]['chromosome_accession']} if listed for MNN2 in manifest): native ORF replaced by MNN2_ISC1beta optimized CDS in the target gene's transcript orientation.
- OCH1 / YGL038C on chromosome VII: native ORF replaced by OCH1_ISC1alpha optimized CDS in the target gene's transcript orientation.
- MNN5 / YJL186W on chromosome X: native ORF replaced by MNN5_ISC1gamma optimized CDS in the target gene's transcript orientation.

Native locus preserved:
- ISC1 / YER019W on chromosome V was preserved because the uploaded optimized-CDS package states that no separate validated standalone ISC1 optimized CDS record is present.

Reference genome total length: {total_ref:,} bp
Edited genome total length: {total_edit:,} bp
Total length delta: {total_edit - total_ref:,} bp

Important limitation: this package is an in-silico depiction/assembly, not wet-lab proof, not off-target screening, and not final HDR donor design.

Main files:
- `CENPK113_7D_triple_lock_edited_genome.fasta.gz`: full edited genome FASTA.
- `edited_chromosomes_II_VII_X.fasta`: only chromosomes containing replacements.
- `optimized_replacement_CDS_transcript_orientation.fasta`: optimized coding candidates as readable CDS/transcript orientation.
- `optimized_replacement_CDS_genomic_insert_orientation.fasta`: exact sequences inserted into the chromosome forward strands.
- `edited_locus_cassettes_with_500bp_CP022_arms_genomic_orientation.fasta`: left arm + inserted replacement + right arm depiction for each replacement locus. Not final HDR donor validation.
- `CENPK113_7D_triple_lock_edit_manifest.csv`: coordinate, replacement, and SHA-256 audit table.
- `CENPK113_7D_triple_lock_edited_features.gff3`: simple feature annotation of edited/preserved loci.
- `build_CENPK113_7D_triple_lock_edited_genome.py`: reproducible build script.
"""
    with open(OUT_DIR / "README_CENPK113_7D_triple_lock_edited_genome.md", "w", encoding="utf-8") as f:
        f.write(readme)

    # Copy this script into package.
    script_src = Path(__file__)
    script_dst = OUT_DIR / script_src.name
    script_dst.write_text(script_src.read_text(encoding="utf-8"), encoding="utf-8")

    # Regenerate checksums after writing README and script.
    checksum_rows = []
    for path in sorted(OUT_DIR.iterdir()):
        if path.is_file() and path.name != "package_file_checksums.csv":
            data = path.read_bytes()
            checksum_rows.append({"file": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    with open(OUT_DIR / "package_file_checksums.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["file", "bytes", "sha256"])
        writer.writeheader()
        writer.writerows(checksum_rows)


def main() -> None:
    for required in [REFERENCE_ZIP, LOCI_ZIP, OPTIMIZED_CDS_ZIP]:
        if not required.exists():
            raise FileNotFoundError(f"Required uploaded input not found: {required}")

    reference_records = read_reference_fasta_from_zip(REFERENCE_ZIP, REFERENCE_FASTA_IN_ZIP)
    specs = load_edit_specs()

    # Verify all native intervals match the uploaded extracted-loci FASTA.
    native_loci_records = parse_fasta_text(read_zip_text(LOCI_ZIP, NATIVE_LOCI_FASTA_IN_ZIP))
    for s in specs:
        ref_seq = reference_records[s.accession]["seq"]
        native = interval(ref_seq, s.start, s.end)
        # Locate matching extracted record by gene prefix.
        matches = [(rid, rec_seq) for rid, (_, rec_seq) in native_loci_records.items() if rid.startswith(s.target_gene + "_")]
        if not matches:
            raise ValueError(f"No extracted native locus FASTA record found for {s.target_gene}")
        rid, extracted = matches[0]
        if native != extracted:
            raise ValueError(f"Reference interval does not match uploaded extracted locus for {s.target_gene}: {rid}")

    edited_records, audit_rows = apply_edits(reference_records, specs)

    # Final verification: exact insertion checks must pass for replacement loci.
    failures = [r for r in audit_rows if r["replacement_inserted_exactly"] not in ("True", "NATIVE_PRESERVED")]
    if failures:
        raise RuntimeError(f"Insertion verification failed: {failures}")

    make_outputs(reference_records, edited_records, specs, audit_rows)

    print(f"Wrote package to: {OUT_DIR}")
    print("Edit summary:")
    for r in audit_rows:
        print(
            f"- {r['target_gene']} {r['systematic_name']} {r['chromosome_accession']}:{r['original_start_1based']}-{r['original_end_1based']} "
            f"{r['strand']} | {r['action']} | delta={r['length_delta_bp']} | verified={r['replacement_inserted_exactly']}"
        )


if __name__ == "__main__":
    main()
