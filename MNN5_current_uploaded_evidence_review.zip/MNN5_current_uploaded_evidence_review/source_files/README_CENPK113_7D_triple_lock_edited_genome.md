# CEN.PK113-7D in-silico Triple-Lock edited genome depiction

Reference used: CEN.PK113-7D GCA_002885995.1 / ASM288599v1 CP022 genome from `ncbi_dataset(1).zip`.

Active coordinate rule: CP022 coordinates from `CENPK113_target_loci_coordinates.csv` were used. Older CM001/GCA_000269885.1 coordinates were not used as edit coordinates.

Edits applied:
- MNN2 / YBR015C on chromosome II (CP022967.1 if listed for MNN2 in manifest): native ORF replaced by MNN2_ISC1beta optimized CDS in the target gene's transcript orientation.
- OCH1 / YGL038C on chromosome VII: native ORF replaced by OCH1_ISC1alpha optimized CDS in the target gene's transcript orientation.
- MNN5 / YJL186W on chromosome X: native ORF replaced by MNN5_ISC1gamma optimized CDS in the target gene's transcript orientation.

Native locus preserved:
- ISC1 / YER019W on chromosome V was preserved because the uploaded optimized-CDS package states that no separate validated standalone ISC1 optimized CDS record is present.

Reference genome total length: 12,280,756 bp
Edited genome total length: 12,280,048 bp
Total length delta: -708 bp

Important limitation: this package is an in-silico depiction/assembly, not wet-lab proof, not off-target screening, and not final HDR donor design.

Main files:
- `CENPK113_7D_triple_lock_edited_genome.fasta.gz`: full edited genome FASTA.
- `edited_chromosomes_II_VII_X.fasta`: only chromosomes containing replacements.
- `optimized_replacement_CDS_transcript_orientation.fasta`: optimized coding candidates as readable CDS/transcript orientation.
- `optimized_replacement_CDS_genomic_insert_orientation.fasta`: exact sequences inserted into the chromosome forward strands.
- `edited_locus_cassettes_with_500bp_CP022_arms_genomic_orientation.fasta`: left arm + inserted replacement + right arm depiction for each replacement locus. Not final HDR donor validation.
- `CENPK113_7D_triple_lock_edit_manifest.csv`: coordinate, replacement, and SHA-256 audit table.
- `CENPK113_7D_triple_lock_edited_features.gff3`: simple feature annotation of edited/preserved loci.
- `build_CENPK113_7D_triple_lock_edited_genome.py`: reproducible build script.
