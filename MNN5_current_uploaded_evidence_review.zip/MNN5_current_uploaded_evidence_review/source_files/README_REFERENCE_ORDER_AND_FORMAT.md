# Local in-silico PCR input format

Use a multi-FASTA reference. Do not paste all chromosomes into one artificial sequence.

## Reference order included in this package
1. UNEDITED_CP022_TARGET_CHROMOSOME records
2. EDITED_TRIPLE_LOCK_FULL_GENOME records
3. EDITED_LOCUS_CASSETTE_500BP_ARMS records
4. DONOR_OR_NATIVE_SMALL_IMPORT records
5. PARTS_ARM_OR_CDS records

## Primer panel input
Use `FINAL_ACTIVE_PRIMER_PANEL_MODIFIED_ONLY.csv`.
Required columns include:
- locus
- assay
- sequence_id
- forward_primer_name
- forward_sequence_5to3
- reverse_primer_name
- reverse_sequence_5to3
- expected_product_bp

The script performs exact-match PCR only. It does not model mismatches or wet-lab PCR behavior.
