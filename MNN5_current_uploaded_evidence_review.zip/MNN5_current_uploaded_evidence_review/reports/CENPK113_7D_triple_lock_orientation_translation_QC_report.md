# CEN.PK113-7D Triple-Lock orientation/translation QC audit
This audit checks the in-silico edited genome depiction generated from the uploaded CP022 CEN.PK113-7D reference, locus-coordinate package, and optimized CDS candidates. It is not wet-lab validation, off-target screening, or functional-expression evidence.
## Bottom-line answers
1. **Replacement orientation:** PASS for MNN2, OCH1, and MNN5. The transcript sequence extracted back from the edited genome matches the uploaded optimized CDS candidate for each locus. MNN2 and OCH1 are minus-strand genes, so their inserted genomic-forward sequences are reverse complements of the readable CDS. MNN5 is plus-strand and was inserted directly.
2. **Promoter/UTR treatment:** The native ORF intervals were replaced. The 500 bp genomic flanks outside each original ORF are preserved on both sides in the edited assembly. Therefore, the model preserves surrounding native regulatory context outside the ORF interval, but it does not prove exact annotated promoter/UTR boundaries because those were not separately annotated in the uploaded coordinate table.
3. **Translation:** PASS for the three inserted CDS records and native ISC1. All translate from ATG to a terminal stop codon with lengths matching the uploaded candidate expectations.
4. **Internal stop codons:** PASS. No internal stop codons were detected in MNN2_ISC1beta, OCH1_ISC1alpha, MNN5_ISC1gamma, or preserved native ISC1.
5. **Primer/gRNA status:** NOT YET VALIDATED. The package does not contain a screened primer or gRNA set. Future designs should use locus-junction logic: one primer in unique genomic sequence outside the edited ORF and one primer in the inserted optimized CDS or locus-specific N-terminal/linker region. Avoid primers entirely inside the conserved ISC1-like payload region unless they are explicitly screened against native ISC1/YER019W. gRNAs also require formal off-target screening against the edited genome and the native ISC1 locus.
6. **Expression/function claims:** NOT YET. RNA, protein, lipid/EV phenotype, and functional assays are required before claiming expression, activity, or biological function.
## Per-locus QC table
| Locus | Strand | Insert/candidate | Orientation | CDS length | Start | Stop | Protein aa incl. stop | Internal stops | 500 bp flanks preserved? |
|---|---:|---|---|---:|---|---|---:|---:|---|
| MNN2 / YBR015C | minus | MNN2_ISC1beta_opt1_optimized_CDS_1422bp_CAI086_stopTAG | PASS | 1422 | ATG | TAG | 474 | 0 | PASS |
| ISC1 / YER019W | plus | native ISC1 preserved | native unchanged | 1434 | ATG | TGA | 478 | 0 | native unchanged |
| OCH1 / YGL038C | minus | OCH1_ISC1alpha_opt1_optimized_CDS_1434bp_CAI086_stopTGA | PASS | 1434 | ATG | TGA | 478 | 0 | PASS |
| MNN5 / YJL186W | plus | MNN5_ISC1gamma_opt1_optimized_CDS_1434bp_CAI086_stopTAA | PASS | 1434 | ATG | TAA | 478 | 0 | PASS |

## Primer/gRNA caution
The inserted candidates contain a protein-identical native ISC1 payload region, even though the DNA is optimized. Protein identity means antibodies or broad payload PCRs may not distinguish native ISC1 from inserted payload expression. Sequence-level assays must therefore be anchored to the edited MNN2/OCH1/MNN5 loci or to candidate-specific optimized/linker DNA.

## Minimal validation hierarchy before publication-style claims
- DNA/genotype: junction PCR/Sanger or amplicon sequencing across MNN2, OCH1, MNN5; native-ORF-loss PCR; whole-genome/off-target check if possible.
- RNA: RT-PCR/qRT-PCR using locus-specific junction or candidate-specific sequence, with native ISC1/YER019W controls.
- Protein: targeted protein detection that distinguishes native ISC1 from payload/chimera where possible; otherwise clearly report only total ISC1-like signal.
- Phenotype/EV: EV particle counts, protein normalization, lipid/ceramide/IPC readout, glycan/lectin assays, and comparison to parent CEN.PK113-7D.
