# MNN5 Reproducible Analysis SOP Package

Use `MNN5_reproducible_analysis_SOP.md` as the master protocol.

Included:
- SOP with test IDs T00-T16
- test registry CSV
- paper claim traceability template
- source register template
- script to check which test outputs exist

Start with:
```bash
python scripts/check_test_outputs.py
```
