# SOURCE_REGISTER template

## SRC01
Name: CEN.PK113-7D genome and annotation
Accession: GCA_000269885.1
URL:
Downloaded date:
Local files:
SHA256:
Used for tests: T01, T02, T03, T05, T12

## SRC02
Name: Uploaded MNN5 BLAST/NEB/IDT archive
Local file: data_raw/uploaded_archive/Archive.zip
Uploaded date:
SHA256:
Used for tests: T00

## SRC03
Name: yeast-GEM model
Version/release:
URL:
Downloaded date:
Local file:
SHA256:
Used for tests: T06, T07

## SRC04
Name: COBRApy
Version:
Install command:
Used for tests: T06

## SRC05
Name: EMBOSS primersearch or equivalent
Version:
Install command:
Used for tests: T03

## SRC06
Name: Intended insert FASTA/GenBank
Local file:
SHA256:
Used for tests: T04, T05, T11, T13, T14
