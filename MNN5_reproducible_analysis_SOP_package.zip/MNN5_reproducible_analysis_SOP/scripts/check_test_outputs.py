#!/usr/bin/env python3
from pathlib import Path
import csv, sys

REQUIRED = {
    "T00": ["reports/T00_uploaded_archive_audit/blast_summary.csv", "reports/T00_uploaded_archive_audit/primer_panel_summary.csv"],
    "T01": ["reports/T01_reference_checksums.sha256"],
    "T02": ["reports/T02_gff_overlap_check.csv"],
    "T03": ["reports/T03_primer_specificity_summary.csv"],
    "T04": ["reports/T04_insert_identity_summary.csv"],
    "T05": ["data_intermediate/T05_MNN5_edit_aware_reference.fasta", "reports/T05_edit_coordinates.bed"],
    "T06": ["reports/T06_fba_result.json", "reports/T06_fba_fluxes.csv"],
    "T07": ["reports/T07_optknock_or_optforce.csv"],
    "T08": ["reports/T08_thermo_feasibility.csv"],
    "T09": ["reports/T09_circuit_model_results.csv"],
    "T10": ["reports/T10_protein_model_summary.csv"],
    "T11": ["reports/T11_resource_burden.csv"],
    "T12": ["reports/T12_crispr_offtargets.csv"],
    "T13": ["reports/T13_codon_usage.csv"],
    "T14": ["reports/T14_sequence_homology.tsv"],
    "T15": ["reports/T15_sensitivity_specificity.csv"],
    "T16": ["reports/T16_wet_lab_validation_summary.csv"],
}

def status_for(test_id):
    needed = REQUIRED[test_id]
    exists = [Path(p).exists() for p in needed]
    if all(exists):
        return "OUTPUT_EXISTS_REVIEW_REQUIRED"
    return "NOT_RUN_OR_MISSING_OUTPUT"

out = Path("reports/test_status_auto.csv")
out.parent.mkdir(exist_ok=True)
with out.open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["test_id", "status", "required_outputs"])
    for tid, files in REQUIRED.items():
        w.writerow([tid, status_for(tid), ";".join(files)])
print(f"Wrote {out}")
