# MNN5 CEN.PK113-7D Reproducible Analysis SOP

Generated: 2026-05-31

## Purpose

This SOP tells you exactly how to run, document, and trace each computational test for the MNN5 CEN.PK113-7D engineering project.

The rule is strict:

> A result can only be used in the research paper if it has:
> 1. raw input file(s),
> 2. exact command or script,
> 3. software/version record,
> 4. raw output file(s),
> 5. parsed summary table,
> 6. checksum,
> 7. test ID linking it to the paper claim.

Anything else must be labeled `NOT_RUN`, `NOT_PROVEN`, or `REQUIRES_WET_LAB`.

---

# 0. Repository setup

Use this folder structure:

```text
MNN5_reproducible_test_harness/
├── README.md
├── SOURCE_REGISTER.md
├── MANIFEST.sha256
├── config/
│   ├── medium_constraints.csv
│   ├── primer_pairs.tsv
│   └── test_registry.csv
├── data_raw/
│   ├── uploaded_archive/
│   ├── reference/
│   ├── yeast_gem/
│   ├── insert/
│   └── wet_lab/
├── data_intermediate/
├── reports/
├── scripts/
├── docs/visual_models/
├── paper_traceability/
└── 99_quarantine_do_not_use/
```

Create a checksum manifest after every major run:

```bash
find . -type f \
  ! -path "./.git/*" \
  ! -name "MANIFEST.sha256" \
  -exec sha256sum {} \; | sort > MANIFEST.sha256
```

---

# 1. Master test registry

Every test gets an ID. Use this in filenames, figure captions, Methods, Results, and Supplementary Tables.

| Test ID | Test | Paper claim allowed only if passed |
|---|---|---|
| T00 | Uploaded archive audit | Uploaded BLAST/QC files exist and are parseable |
| T01 | Reference acquisition/checksum | Exact CEN.PK113-7D reference is traceable |
| T02 | GFF3 overlap / ORF-boundary check | 725 bp assay overlaps MNN5 or not |
| T03 | Genome-wide primer specificity | Primers are unique or off-targets are documented |
| T04 | Insert identity check | Full insert identity is verified |
| T05 | Edit-aware junction simulation | Expected edited junction sequences are detectable |
| T06 | FBA / single-gene knockout | MNN5 knockout growth/flux effect is reproducibly modeled |
| T07 | OptKnock / OptForce | Engineering targets are predicted by real optimization output |
| T08 | Thermodynamic feasibility | Reaction ΔG evidence exists |
| T09 | Genetic circuit ODE/Boolean/stochastic model | Circuit behavior is simulated under defined assumptions |
| T10 | Protein/AlphaFold/docking/MD | Protein-level claims are supported by raw outputs |
| T11 | Host burden/toxicity | Burden/toxicity is calculated from defined expression inputs |
| T12 | CRISPR off-target scoring | Guide specificity is evaluated against exact genome |
| T13 | Codon usage / CAI | Insert coding sequence matches yeast codon usage metrics |
| T14 | Sequence homology / anti-screening | Sequence lacks flagged homology under defined database search |
| T15 | Synthetic FASTQ + sensitivity/specificity | Pipeline detects known edits with measured false positive/negative behavior |
| T16 | Wet-lab validation | PCR/Sanger/amplicon/WGS confirms genotype |

---

# 2. Source register

Keep `SOURCE_REGISTER.md` updated. Each source must list:

```text
Source ID:
Name:
URL or accession:
Downloaded date:
Downloaded by:
Local file path:
SHA256:
Reason used:
Tests depending on this source:
```

Minimum sources:

```text
SRC01 = CEN.PK113-7D GCA_000269885.1 genome FASTA/GFF3
SRC02 = uploaded BLAST/NEB/IDT archive
SRC03 = yeast-GEM release model file
SRC04 = COBRApy version
SRC05 = EMBOSS primersearch version or equivalent primer specificity tool
SRC06 = insert FASTA/GenBank
SRC07 = AlphaGenome raw output, only if actually used
SRC08 = wet-lab PCR/Sanger/amplicon files, if available
```

---

# 3. T00 — Audit uploaded archive

## Goal
Parse uploaded BLAST and primer-QC records. This does not prove editing. It only proves uploaded design/QC records exist.

## Inputs
```text
data_raw/uploaded_archive/Archive.zip
```

## Command
```bash
python scripts/00_audit_uploaded_archive.py \
  --archive data_raw/uploaded_archive/Archive.zip \
  --out reports/T00_uploaded_archive_audit
```

## Required outputs
```text
reports/T00_uploaded_archive_audit/blast_summary.csv
reports/T00_uploaded_archive_audit/primer_panel_summary.csv
reports/T00_uploaded_archive_audit/evidence_status.csv
```

## Pass rule
PASS only if BLAST files and primer-QC files are parsed without error.

## Paper wording allowed
“The uploaded design package contained BLAST placement records and first-pass primer thermodynamic QC records.”

## Paper wording not allowed
“The edit was validated.”
“The junctions were confirmed.”
“The organism was computationally verified.”

---

# 4. T01 — Download exact CEN.PK113-7D reference

## Goal
Download and checksum the exact reference assembly used for all coordinate-based analyses.

## Source
Use `GCA_000269885.1`, CEN.PK113-7D ASM26988v1.

## Command
```bash
mkdir -p data_raw/reference

datasets download genome accession GCA_000269885.1 \
  --include genome,gff3,gbff,seq-report \
  --filename data_raw/reference/GCA_000269885.1_CENPK1137D_dataset.zip

unzip -o data_raw/reference/GCA_000269885.1_CENPK1137D_dataset.zip \
  -d data_raw/reference/GCA_000269885.1_CENPK1137D_dataset

find data_raw/reference -type f \
  \( -name "*.fna" -o -name "*.gff" -o -name "*.gff3" -o -name "*.gbff" -o -name "*.jsonl" \) \
  -exec sha256sum {} \; | sort > reports/T01_reference_checksums.sha256
```

## Required outputs
```text
data_raw/reference/...genomic.fna
data_raw/reference/...genomic.gff or .gff3
reports/T01_reference_checksums.sha256
```

## Pass rule
PASS only if FASTA and GFF3/GFF are present and checksummed.

## Paper wording allowed
“All coordinate-based tests used the CEN.PK113-7D GCA_000269885.1 reference genome and annotation.”

---

# 5. T02 — Verify GFF3 overlap and ORF boundary

## Goal
Determine whether `CM001531.1:62896-63620` overlaps MNN5/YJL186W and whether it is a full ORF, partial CDS, internal assay segment, or noncoding.

## Inputs
```text
reports/T00_uploaded_archive_audit/blast_summary.csv
data_raw/reference/...genomic.gff3
```

## Command
```bash
python scripts/02_verify_gff_overlap.py \
  --gff3 data_raw/reference/path/to/genomic.gff3 \
  --blast-summary reports/T00_uploaded_archive_audit/blast_summary.csv \
  --target-name MNN5 \
  --target-systematic YJL186W \
  --out reports/T02_gff_overlap_check.csv
```

## Required outputs
```text
reports/T02_gff_overlap_check.csv
reports/T02_orf_boundary_decision.md
```

## Pass rule
PASS only if overlap is determined from GFF3.

## Decision labels
Use exactly one:

```text
FULL_ORF_CONFIRMED
PARTIAL_CDS_OR_INTERNAL_SEGMENT
OVERLAPS_DIFFERENT_FEATURE
NONCODING_OR_INTERGENIC
ANNOTATION_NOT_FOUND
```

## Paper wording allowed
Only use the label generated by this test.

---

# 6. T03 — Genome-wide primer specificity

## Goal
Check whether each primer pair gives only the intended amplicon under the allowed mismatch setting.

## Recommended tool
EMBOSS `primersearch`, or your own exact-match/mismatch search script if EMBOSS is unavailable.

## Inputs
```text
data_raw/reference/...genomic.fna
config/primer_pairs.tsv
```

## primer_pairs.tsv format
```text
Assay<TAB>Forward<TAB>Reverse<TAB>Expected_Product_bp
Left junction<TAB>TGGCATCTGTGAGGTGGAAC<TAB>AACATCATTGTGAACGGAGCAG<TAB>554
Insert internal<TAB>CTGCTCCGTTCACAATGATG<TAB>CACTAGACCAGCTTCTTGTGT<TAB>682
Right junction<TAB>TAACTCGCCATCCGACCTTG<TAB>AATTCTAAGAACATGCTACCGCGA<TAB>457
Native ORF loss<TAB>...<TAB>...<TAB>725
```

## EMBOSS input format
Create:
```text
config/primersearch_input.txt
```

Format:
```text
Left_junction TGGCATCTGTGAGGTGGAAC AACATCATTGTGAACGGAGCAG
Insert_internal CTGCTCCGTTCACAATGATG CACTAGACCAGCTTCTTGTGT
Right_junction TAACTCGCCATCCGACCTTG AATTCTAAGAACATGCTACCGCGA
```

## Command
For roughly 3 mismatches on a 20 bp primer, use 15% mismatch. For longer primers, record the exact percent and rationale.

```bash
primersearch \
  -seqall data_raw/reference/path/to/genomic.fna \
  -infile config/primersearch_input.txt \
  -mismatchpercent 15 \
  -outfile reports/T03_primersearch_15pct.out
```

## Parse output
```bash
python scripts/03_parse_primersearch.py \
  --primersearch reports/T03_primersearch_15pct.out \
  --expected config/primer_pairs.tsv \
  --out reports/T03_primer_specificity_summary.csv
```

## Pass rule
PASS if each assay has exactly one intended genomic hit within expected size tolerance and no conflicting off-target amplicons.

## Paper wording allowed
“Genome-wide in silico PCR produced [N] predicted amplicon(s) under [X]% mismatch settings.”

Do not say primers are experimentally specific until wet-lab PCR confirms.

---

# 7. T04 — Insert identity check

## Goal
Verify the full insert sequence before claiming insert-specific PCR or cargo identity.

## Inputs
```text
data_raw/insert/MNN5_insert.fasta or .gb
data_raw/reference/...genomic.fna
```

## Commands
Basic length and composition:
```bash
python scripts/04_insert_identity_check.py \
  --insert data_raw/insert/MNN5_insert.fasta \
  --out reports/T04_insert_identity_summary.csv
```

Optional BLAST:
```bash
makeblastdb -in data_raw/reference/path/to/genomic.fna -dbtype nucl -out data_intermediate/T04_cenpk_db

blastn \
  -query data_raw/insert/MNN5_insert.fasta \
  -db data_intermediate/T04_cenpk_db \
  -out reports/T04_insert_vs_cenpk_blast.tsv \
  -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore"
```

## Pass rule
PASS only if the insert file exists, length is recorded, sequence is unambiguous, and expected identity/source is documented.

---

# 8. T05 — Edit-aware reference and junction simulation

## Goal
Create a reference sequence representing the intended edited locus and test whether primers detect the engineered junctions.

## Inputs required
```text
data_raw/reference/...genomic.fna
reports/T02_gff_overlap_check.csv
data_raw/insert/MNN5_insert.fasta
config/edit_design.yaml
```

## edit_design.yaml
```yaml
edit_id: MNN5_EDIT_V1
reference_accession: GCA_000269885.1
chromosome: CM001531.1
left_arm_start: null
left_arm_end: null
deleted_region_start: 62896
deleted_region_end: 63620
right_arm_start: null
right_arm_end: null
insert_fasta: data_raw/insert/MNN5_insert.fasta
```

## Command
```bash
python scripts/05_build_edit_aware_reference.py \
  --design config/edit_design.yaml \
  --reference data_raw/reference/path/to/genomic.fna \
  --out-fasta data_intermediate/T05_MNN5_edit_aware_reference.fasta \
  --out-bed reports/T05_edit_coordinates.bed
```

## Pass rule
PASS only if edited reference is built from documented coordinates and insert sequence.

## Paper wording allowed
“The expected edited reference was generated computationally from the documented reference coordinates and insert sequence.”

---

# 9. T06 — FBA / MFA single-gene knockout

## Goal
Model growth and flux consequences of an MNN5/YJL186W knockout using a real yeast GEM.

## Inputs
```text
data_raw/yeast_gem/yeast-GEM.xml
config/medium_constraints.csv
config/fba_gene_targets.csv
```

## medium_constraints.csv
```csv
reaction_id,lower_bound,upper_bound,reason
r_1714,-10,1000,glucose uptake example - replace with chosen medium
r_1992,-1000,1000,oxygen exchange example - verify reaction ID in model
```

## fba_gene_targets.csv
```csv
test_id,gene_id,description
T06,YJL186W,MNN5 knockout
```

## Command
```bash
python scripts/06_fba_yeastgem_knockout.py \
  --model data_raw/yeast_gem/yeast-GEM.xml \
  --medium config/medium_constraints.csv \
  --targets config/fba_gene_targets.csv \
  --out-json reports/T06_fba_result.json \
  --out-flux-csv reports/T06_fba_fluxes.csv
```

## Required outputs
```text
reports/T06_fba_result.json
reports/T06_fba_fluxes.csv
reports/T06_fba_solver_log.txt
```

## Pass rule
PASS only if:
1. model loads,
2. gene exists in the model,
3. WT optimization succeeds,
4. KO optimization succeeds,
5. solver status is optimal or explicitly reported otherwise.

## Paper wording allowed
“Under the specified GEM, medium constraints, and solver, simulated deletion of [gene] produced [value] relative growth.”

Never generalize beyond the model and constraints.

---

# 10. T07 — OptKnock / OptForce

## Goal
Only run this if you have a target product reaction.

## Required input
```text
config/target_product_reaction.txt
```

Example:
```text
TARGET_REACTION_ID=r_xxxx
```

## If no target compound exists
Set status:
```text
NOT_APPLICABLE_NO_TARGET_PRODUCT_DEFINED
```

## Pass rule
PASS only if target reaction exists and optimization output is saved.

---

# 11. T08 — Thermodynamic feasibility

## Goal
Evaluate whether pathway reactions are directionally feasible under defined assumptions.

## Inputs
```text
reports/T06_fba_fluxes.csv
config/thermo_reactions.csv
```

## Minimum thermo table
```csv
reaction_id,reaction_equation,delta_g_kj_mol,source,conditions
R_EXAMPLE,A + B -> C,-12.4,literature_or_eQuilibrator,pH7 ionic strength stated
```

## Command
```bash
python scripts/08_thermo_feasibility.py \
  --reactions config/thermo_reactions.csv \
  --fluxes reports/T06_fba_fluxes.csv \
  --out reports/T08_thermo_feasibility.csv
```

## Pass rule
PASS only if every ΔG value has a source and condition.

## If no ΔG source exists
Set:
```text
NOT_RUN_NO_THERMO_INPUTS
```

---

# 12. T09 — Genetic circuit ODE/Boolean/stochastic model

## Goal
Run only if there is an actual genetic circuit design. A deletion assay is not a complex circuit by itself.

## Required inputs
```text
config/circuit_model.yaml
```

Example:
```yaml
circuit_id: MNN5_ORF_LOSS_ASSAY
model_type: boolean
nodes:
  MNN5_native_ORF_present:
    states: [0, 1]
  MNN5_native_amplicon_detected:
    rule: "MNN5_native_ORF_present"
```

## Command
```bash
python scripts/09_circuit_model_check.py \
  --model config/circuit_model.yaml \
  --out reports/T09_circuit_model_results.csv
```

## Pass rule
PASS only if assumptions and equations/rules are saved.

## Paper wording allowed
“The assay logic was represented as a Boolean detection model.”

Do not claim cellular circuit stability unless you model an actual expressed circuit.

---

# 13. T10 — Protein / AlphaFold / docking / MD

## Goal
Support protein-level claims only with correct protein accession and raw outputs.

## Inputs
```text
config/protein_accessions.csv
data_raw/protein/
```

## protein_accessions.csv
```csv
gene,systematic_id,organism,uniprot_accession,source_url,notes
MNN5,YJL186W,Saccharomyces cerevisiae,TO_BE_VERIFIED,URL,Do not use P39107 unless proven
```

## Minimum requirements
For AlphaFold:
```text
PDB/CIF file
accession source
date downloaded
pLDDT/source metadata
```

For docking:
```text
protein structure
ligand structure
docking tool/version
config
raw docking output
```

For MD:
```text
force field
solvent model
temperature
time step
simulation length
trajectory
energy/RMSD output
```

## If not available
Set:
```text
NOT_RUN_NO_PROTEIN_INPUTS
```

---

# 14. T11 — Host burden / toxicity

## Goal
Estimate expression burden only if insert coding sequence and expression assumptions exist.

## Inputs
```text
data_raw/insert/MNN5_insert.fasta
config/expression_assumptions.csv
```

## expression_assumptions.csv
```csv
construct,protein_length_aa,copies_per_cell,expression_rate_assumption,source
insert_name,,,, 
```

## Command
```bash
python scripts/11_resource_burden.py \
  --insert data_raw/insert/MNN5_insert.fasta \
  --assumptions config/expression_assumptions.csv \
  --out reports/T11_resource_burden.csv
```

## Pass rule
PASS only if all assumptions have sources.

---

# 15. T12 — CRISPR off-target scoring

## Goal
Run only if a CRISPR guide sequence is actually provided.

## Inputs
```text
config/crispr_guides.csv
data_raw/reference/...genomic.fna
```

## crispr_guides.csv
```csv
guide_id,sequence,pam,enzyme,target_chrom,target_start,target_end
gRNA1,NNNNNNNNNNNNNNNNNNNN,NGG,SpCas9,CM001531.1,,
```

## Command
```bash
python scripts/12_offtarget_crispr_scan.py \
  --fasta data_raw/reference/path/to/genomic.fna \
  --guides config/crispr_guides.csv \
  --max-mismatches 3 \
  --out reports/T12_crispr_offtargets.csv
```

## Pass rule
PASS only if guide input is real and every genomic hit is reported.

## If no CRISPR guide exists
Set:
```text
NOT_APPLICABLE_NO_CRISPR_GUIDE
```

---

# 16. T13 — Codon optimization / CAI

## Goal
Evaluate coding sequence only if insert is meant to be translated.

## Inputs
```text
data_raw/insert/MNN5_insert_cds.fasta
config/yeast_codon_usage.tsv
```

## Command
```bash
python scripts/13_codon_usage_check.py \
  --cds data_raw/insert/MNN5_insert_cds.fasta \
  --codon-table config/yeast_codon_usage.tsv \
  --out reports/T13_codon_usage.csv
```

## Pass rule
PASS if CDS length is divisible by 3, no internal stops exist, CAI/codon usage metrics are calculated, and codon table source is recorded.

---

# 17. T14 — Sequence homology / anti-screening

## Goal
Avoid unsupported safety claims. Only report what database was searched, when, and with what thresholds.

## Inputs
```text
data_raw/insert/MNN5_insert.fasta
```

## Command template
```bash
blastn \
  -query data_raw/insert/MNN5_insert.fasta \
  -db path/to/approved_database \
  -out reports/T14_sequence_homology.tsv \
  -outfmt "6 qseqid sseqid pident length evalue bitscore stitle"
```

## Pass rule
PASS only if database name, version/date, thresholds, and output are saved.

## Paper wording allowed
“Under the stated database and threshold, no hits above [threshold] were detected.”

Do not say “safe” or “nonhazardous” from this alone.

---

# 18. T15 — Synthetic FASTQ and sensitivity/specificity

## Goal
Test the pipeline, not the biological edit.

## Inputs
```text
data_intermediate/T05_MNN5_edit_aware_reference.fasta
config/synthetic_read_design.yaml
```

## synthetic_read_design.yaml
```yaml
read_length: 150
coverage_values: [5, 10, 20, 50]
error_rates: [0.0, 0.001, 0.01]
replicates: 5
```

## Commands
```bash
python scripts/15_generate_synthetic_fastq.py \
  --reference data_intermediate/T05_MNN5_edit_aware_reference.fasta \
  --design config/synthetic_read_design.yaml \
  --out-dir data_intermediate/T15_fastq

python scripts/15_detect_edit_from_fastq.py \
  --fastq-dir data_intermediate/T15_fastq \
  --reference-wt data_raw/reference/path/to/genomic.fna \
  --reference-edit data_intermediate/T05_MNN5_edit_aware_reference.fasta \
  --out reports/T15_detection_results.csv

python scripts/15_sensitivity_specificity.py \
  --detections reports/T15_detection_results.csv \
  --out reports/T15_sensitivity_specificity.csv
```

## Pass rule
PASS only if true positives, false positives, true negatives, and false negatives are counted from known simulated conditions.

## Paper wording allowed
“The bioinformatics detection pipeline identified simulated edit-containing reads with [sensitivity/specificity] under the tested conditions.”

---

# 19. T16 — Wet-lab validation

## Goal
Only real experimental data can validate the engineered strain.

## Required files
```text
data_raw/wet_lab/gel_images/
data_raw/wet_lab/sanger_ab1/
data_raw/wet_lab/sanger_fastq_or_fasta/
data_raw/wet_lab/sample_key.csv
```

## sample_key.csv
```csv
sample_id,strain,parent_or_candidate,assay,date,operator,raw_file,notes
```

## Pass rule
PASS if sample IDs match raw files, expected amplicon sizes are observed, and Sanger/amplicon alignments confirm junctions.

---

# 20. Paper traceability table

Every paper claim must map to evidence.

Use:

```csv
paper_claim_id,claim_text,test_id,status,evidence_file,source_id,allowed_wording
C01,Uploaded regions map to CEN.PK113-7D chromosome X,T00,PROVEN_FROM_UPLOADED_RECORDS,reports/T00_uploaded_archive_audit/blast_summary.csv,SRC02,BLAST placement evidence
C02,725 bp segment is full MNN5 ORF,T02,NOT_PROVEN,reports/T02_gff_overlap_check.csv,SRC01,Do not claim unless FULL_ORF_CONFIRMED
C03,MNN5 knockout has minimal growth impact,T06,NOT_RUN,reports/T06_fba_result.json,SRC03,Do not claim until FBA succeeds
```

---

# 21. Final reproducibility checklist before writing Results

Before a result goes in the paper, confirm:

```text
[ ] Test ID assigned
[ ] Raw input exists
[ ] Source registered
[ ] Checksum recorded
[ ] Software version recorded
[ ] Command saved
[ ] Raw output saved
[ ] Parsed summary saved
[ ] Pass/fail rule applied
[ ] Claim wording matches evidence level
[ ] Figure/table caption cites test ID and evidence file
```
