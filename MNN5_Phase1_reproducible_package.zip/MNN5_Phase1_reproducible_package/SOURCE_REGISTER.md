# SOURCE_REGISTER

Every source used in this project must be registered before it can support a paper claim.

## SRC01
Name: CEN.PK113-7D genome and annotation
Accession/URL: GCA_000269885.1
Downloaded date:
Local file path:
SHA256 checksum:
Used for tests: T01, T02, T03

## SRC02
Name: Uploaded MNN5 BLAST/NEB/IDT archive
Local file path: data_raw/uploaded_archive/Archive.zip
SHA256 checksum:
Used for tests: T00

## SRC03
Name: Primer pair configuration
Local file path: config/primer_pairs.tsv
SHA256 checksum:
Used for tests: T03
