#!/usr/bin/env python3
"""
T02_verify_gff_overlap.py

Purpose:
  Determine whether BLAST intervals from blast_summary.csv overlap the target
  MNN5/YJL186W annotation in the exact CEN.PK113-7D GFF/GFF3 file.

This script does not prove a genome edit. It only classifies uploaded BLAST
intervals relative to reference annotation.
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path
from urllib.parse import unquote

TARGET_FEATURE_TYPES_PRIORITY = ["gene", "mRNA", "transcript", "CDS"]


def parse_attrs(attr_text: str) -> dict[str, str]:
    attrs = {}
    attr_text = unquote(attr_text.strip())
    if "=" in attr_text:
        for part in attr_text.split(";"):
            if not part.strip() or "=" not in part:
                continue
            k, v = part.split("=", 1)
            attrs[k.strip()] = v.strip()
    else:
        for m in re.finditer(r'(\S+)\s+"([^"]+)"', attr_text):
            attrs[m.group(1)] = m.group(2)
    return attrs


def feature_matches(attrs_text: str, target_name: str, target_systematic: str) -> bool:
    text = unquote(attrs_text).lower()
    terms = [target_name.lower(), target_systematic.lower()]
    return any(term and term in text for term in terms)


def load_gff_features(gff_path: Path) -> list[dict]:
    features = []
    with gff_path.open("r", encoding="utf-8", errors="replace") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 9:
                continue
            seqid, source, ftype, start, end, score, strand, phase, attrs = parts[:9]
            try:
                start_i, end_i = int(start), int(end)
            except ValueError:
                continue
            if start_i > end_i:
                start_i, end_i = end_i, start_i
            parsed = parse_attrs(attrs)
            features.append({
                "seqid": seqid,
                "source": source,
                "type": ftype,
                "start": start_i,
                "end": end_i,
                "strand": strand,
                "phase": phase,
                "attrs_raw": unquote(attrs),
                "attrs": parsed,
                "line_no": line_no,
            })
    return features


def same_seqid(a: str, b: str) -> bool:
    if a == b:
        return True
    return a.split(".")[0] == b.split(".")[0]


def overlaps(a_start: int, a_end: int, b_start: int, b_end: int) -> bool:
    return a_start <= b_end and a_end >= b_start


def contained_within(inner_start: int, inner_end: int, outer_start: int, outer_end: int) -> bool:
    return inner_start >= outer_start and inner_end <= outer_end


def choose_target_feature(features: list[dict], target_name: str, target_systematic: str) -> dict | None:
    matches = [f for f in features if feature_matches(f["attrs_raw"], target_name, target_systematic)]
    if not matches:
        return None
    for ftype in TARGET_FEATURE_TYPES_PRIORITY:
        typed = [f for f in matches if f["type"].lower() == ftype.lower()]
        if typed:
            return sorted(typed, key=lambda x: (x["end"] - x["start"]), reverse=True)[0]
    return sorted(matches, key=lambda x: (x["end"] - x["start"]), reverse=True)[0]


def classify_interval(chrom: str, start: int, end: int, target: dict | None, overlaps_any: list[dict]) -> str:
    if target is None:
        return "ANNOTATION_NOT_FOUND"
    if not same_seqid(chrom, target["seqid"]):
        return "TARGET_ON_DIFFERENT_SEQUENCE"
    if start == target["start"] and end == target["end"]:
        return "FULL_FEATURE_INTERVAL_CONFIRMED"
    if contained_within(start, end, target["start"], target["end"]):
        return "INTERNAL_TARGET_SEGMENT"
    if overlaps(start, end, target["start"], target["end"]):
        return "PARTIAL_TARGET_OVERLAP"
    if overlaps_any:
        return "OVERLAPS_DIFFERENT_FEATURE"
    return "NONCODING_OR_INTERGENIC"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gff3", required=True)
    ap.add_argument("--blast-summary", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--decision-md", default=None)
    ap.add_argument("--target-name", default="MNN5")
    ap.add_argument("--target-systematic", default="YJL186W")
    args = ap.parse_args()

    gff_path = Path(args.gff3)
    blast_path = Path(args.blast_summary)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    features = load_gff_features(gff_path)
    target = choose_target_feature(features, args.target_name, args.target_systematic)

    rows = []
    with blast_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        required = {"Assay", "Hit_Chromosome", "Hit_Start", "Hit_End"}
        missing = sorted(required - set(reader.fieldnames or []))
        if missing:
            raise SystemExit(f"Missing required blast_summary columns: {missing}")

        for row in reader:
            chrom = row["Hit_Chromosome"].strip()
            start, end = int(float(row["Hit_Start"])), int(float(row["Hit_End"]))
            if start > end:
                start, end = end, start

            overlapping_features = [
                feat for feat in features
                if same_seqid(chrom, feat["seqid"]) and overlaps(start, end, feat["start"], feat["end"])
            ]

            classification = classify_interval(chrom, start, end, target, overlapping_features)

            target_interval = "NOT_FOUND"
            target_type = "NOT_FOUND"
            target_attrs = "NOT_FOUND"
            if target:
                target_interval = f'{target["seqid"]}:{target["start"]}-{target["end"]}({target["strand"]})'
                target_type = target["type"]
                target_attrs = target["attrs_raw"]

            overlap_summary = []
            for feat in overlapping_features[:20]:
                overlap_summary.append(
                    f'{feat["type"]}:{feat["seqid"]}:{feat["start"]}-{feat["end"]}:{feat["attrs_raw"][:120]}'
                )

            rows.append({
                "source_file": row.get("Source_File", ""),
                "assay": row["Assay"],
                "blast_interval": f"{chrom}:{start}-{end}",
                "target_name": args.target_name,
                "target_systematic": args.target_systematic,
                "chosen_target_feature_type": target_type,
                "chosen_target_interval": target_interval,
                "classification": classification,
                "overlapping_feature_count": len(overlapping_features),
                "overlapping_features_truncated": " | ".join(overlap_summary),
                "chosen_target_attributes": target_attrs[:500],
            })

    fieldnames = [
        "source_file", "assay", "blast_interval", "target_name", "target_systematic",
        "chosen_target_feature_type", "chosen_target_interval", "classification",
        "overlapping_feature_count", "overlapping_features_truncated",
        "chosen_target_attributes",
    ]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

    decision_path = Path(args.decision_md) if args.decision_md else out_path.with_name("T02_orf_boundary_decision.md")
    with decision_path.open("w", encoding="utf-8") as f:
        f.write("# T02 ORF-boundary / annotation overlap decision\n\n")
        f.write(f"Target requested: `{args.target_name}` / `{args.target_systematic}`\n\n")
        if target:
            f.write(f"Chosen target feature: `{target['type']}` at `{target['seqid']}:{target['start']}-{target['end']}({target['strand']})`\n\n")
            f.write(f"Attributes: `{target['attrs_raw']}`\n\n")
        else:
            f.write("No target feature matching MNN5/YJL186W was found in the GFF/GFF3 attributes.\n\n")
        f.write("## Interval classifications\n\n")
        for r in rows:
            f.write(f"- `{r['assay']}` `{r['blast_interval']}` → **{r['classification']}**\n")
        f.write("\n## Allowed wording\n\n")
        f.write("Use the exact classification labels above. Do not call the 725 bp assay the full MNN5 ORF unless the classification is `FULL_FEATURE_INTERVAL_CONFIRMED` and the chosen target feature is the correct ORF/CDS feature.\n")

    print(f"T02 Complete. Wrote {out_path} and {decision_path}")


if __name__ == "__main__":
    main()
