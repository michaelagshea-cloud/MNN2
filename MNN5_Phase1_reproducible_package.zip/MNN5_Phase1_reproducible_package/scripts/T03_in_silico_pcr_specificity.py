#!/usr/bin/env python3
"""
T03_in_silico_pcr_specificity.py

Self-contained in silico PCR specificity screen.

Inputs:
  --fasta reference genome FASTA
  --primers primer pairs TSV/CSV with columns:
      Assay, FWD_Seq, REV_Seq, Expected_Product_bp
    Optional:
      Tolerance_bp

Outputs:
  --out raw amplicon hits CSV
  --summary summary/pass-fail CSV
"""

from __future__ import annotations

import argparse
import csv
import gzip
from pathlib import Path


def open_text(path: Path):
    if str(path).endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return path.open("r", encoding="utf-8", errors="replace")


def read_fasta(path: Path) -> dict[str, str]:
    seqs = {}
    name = None
    chunks = []
    with open_text(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(chunks).upper()
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line)
    if name is not None:
        seqs[name] = "".join(chunks).upper()
    if not seqs:
        raise SystemExit(f"No sequences found in FASTA: {path}")
    return seqs


COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def rc(seq: str) -> str:
    return seq.translate(COMP)[::-1].upper()


def mismatches(a: str, b: str) -> int:
    return sum(1 for x, y in zip(a.upper(), b.upper()) if x != y)


def find_hits(seq: str, primer: str, max_mismatches: int) -> list[tuple[int, int]]:
    p = primer.upper()
    n = len(p)
    hits = []
    if n == 0 or len(seq) < n:
        return hits
    for i in range(0, len(seq) - n + 1):
        window = seq[i:i+n]
        mm = mismatches(window, p)
        if mm <= max_mismatches:
            hits.append((i + 1, mm))
    return hits


def read_primers(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8", errors="replace").splitlines()
    first = next((line for line in text if line.strip()), "")
    delimiter = "\t" if "\t" in first else ","
    rows = []
    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        required = {"Assay", "FWD_Seq", "REV_Seq", "Expected_Product_bp"}
        missing = sorted(required - set(reader.fieldnames or []))
        if missing:
            raise SystemExit(f"Primer file missing required columns: {missing}. Required: {sorted(required)}")
        for row in reader:
            row["FWD_Seq"] = row["FWD_Seq"].strip().upper()
            row["REV_Seq"] = row["REV_Seq"].strip().upper()
            row["Expected_Product_bp"] = int(float(row["Expected_Product_bp"]))
            row["Tolerance_bp"] = int(float(row.get("Tolerance_bp") or 50))
            if "PASTE_" in row["FWD_Seq"] or "PASTE_" in row["REV_Seq"]:
                raise SystemExit(f"Primer row contains placeholder sequence: {row['Assay']}")
            rows.append(row)
    if not rows:
        raise SystemExit("No primer rows found.")
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fasta", required=True)
    ap.add_argument("--primers", required=True)
    ap.add_argument("--max-mismatches", type=int, default=3)
    ap.add_argument("--max-product", type=int, default=3000)
    ap.add_argument("--out", required=True, help="Raw amplicon hits CSV")
    ap.add_argument("--summary", default=None, help="Summary/pass-fail CSV")
    args = ap.parse_args()

    seqs = read_fasta(Path(args.fasta))
    primer_rows = read_primers(Path(args.primers))
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path = Path(args.summary) if args.summary else out_path.with_name("T03_primer_specificity_summary.csv")

    raw_rows = []
    summary_rows = []

    for primer in primer_rows:
        assay = primer["Assay"]
        fwd = primer["FWD_Seq"]
        rev = primer["REV_Seq"]
        rev_rc = rc(rev)
        expected = primer["Expected_Product_bp"]
        tol = primer["Tolerance_bp"]

        assay_hit_count = 0
        intended_size_hits = 0
        off_size_hits = 0

        for chrom, seq in seqs.items():
            f_hits = find_hits(seq, fwd, args.max_mismatches)
            r_hits = find_hits(seq, rev_rc, args.max_mismatches)

            for f_start, f_mm in f_hits:
                for r_start, r_mm in r_hits:
                    if r_start <= f_start:
                        continue
                    product_bp = (r_start + len(rev) - 1) - f_start + 1
                    if product_bp > args.max_product:
                        continue

                    assay_hit_count += 1
                    within_expected = abs(product_bp - expected) <= tol
                    if within_expected:
                        intended_size_hits += 1
                    else:
                        off_size_hits += 1

                    raw_rows.append({
                        "assay": assay,
                        "chromosome": chrom,
                        "fwd_start_1based": f_start,
                        "rev_start_1based_plus_strand_rc": r_start,
                        "product_bp": product_bp,
                        "expected_product_bp": expected,
                        "tolerance_bp": tol,
                        "within_expected_size": within_expected,
                        "fwd_mismatches": f_mm,
                        "rev_mismatches": r_mm,
                        "max_mismatches_allowed": args.max_mismatches,
                        "fwd_seq": fwd,
                        "rev_seq": rev,
                    })

        if assay_hit_count == 0:
            status = "FAIL_NO_AMPLICON_FOUND"
        elif intended_size_hits == 1 and off_size_hits == 0 and assay_hit_count == 1:
            status = "PASS_SINGLE_EXPECTED_AMPLICON"
        elif intended_size_hits >= 1 and assay_hit_count > 1:
            status = "FAIL_EXPECTED_PLUS_ADDITIONAL_AMPLICONS"
        elif intended_size_hits == 0 and assay_hit_count > 0:
            status = "FAIL_ONLY_OFF_SIZE_AMPLICONS"
        else:
            status = "REVIEW_REQUIRED"

        summary_rows.append({
            "assay": assay,
            "status": status,
            "total_amplicons_found": assay_hit_count,
            "expected_size_amplicons": intended_size_hits,
            "off_size_amplicons": off_size_hits,
            "expected_product_bp": expected,
            "tolerance_bp": tol,
            "max_mismatches_allowed_per_primer": args.max_mismatches,
            "max_product_bp": args.max_product,
        })

    raw_fields = [
        "assay", "chromosome", "fwd_start_1based", "rev_start_1based_plus_strand_rc",
        "product_bp", "expected_product_bp", "tolerance_bp", "within_expected_size",
        "fwd_mismatches", "rev_mismatches", "max_mismatches_allowed", "fwd_seq", "rev_seq"
    ]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=raw_fields)
        w.writeheader()
        w.writerows(raw_rows)

    summary_fields = [
        "assay", "status", "total_amplicons_found", "expected_size_amplicons",
        "off_size_amplicons", "expected_product_bp", "tolerance_bp",
        "max_mismatches_allowed_per_primer", "max_product_bp"
    ]
    with summary_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=summary_fields)
        w.writeheader()
        w.writerows(summary_rows)

    print(f"T03 Complete. Raw hits: {out_path}; summary: {summary_path}")


if __name__ == "__main__":
    main()
