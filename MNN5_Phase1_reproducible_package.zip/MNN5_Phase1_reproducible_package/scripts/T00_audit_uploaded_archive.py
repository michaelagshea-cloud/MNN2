#!/usr/bin/env python3
"""
T00_audit_uploaded_archive.py

Parses uploaded MNN5 Archive.zip into BLAST and primer-QC summaries.
This does not prove an edit. It only summarizes uploaded design/QC evidence.
"""

from __future__ import annotations

import argparse
import csv
import re
import shutil
import zipfile
import hashlib
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_blast(path: Path) -> dict:
    txt = path.read_text(encoding="utf-8", errors="replace")
    d = {
        "Source_File": path.name,
        "SHA256": sha256(path),
    }

    # Known assay mapping from filenames
    name = path.name.upper()
    if "LEFT" in name:
        d["Assay"] = "Left native/outside region"
    elif "RIGHT" in name:
        d["Assay"] = "Right native/outside region"
    elif "ORF" in name:
        d["Assay"] = "Native ORF internal segment"
    else:
        d["Assay"] = path.stem

    m = re.search(r"Query #1:.*?Length:\s*(\d+)", txt, flags=re.S)
    if m:
        d["Sequence_Length_bp"] = int(m.group(1))
    else:
        m = re.search(r"Length:\s*(\d+)", txt)
        d["Sequence_Length_bp"] = int(m.group(1)) if m else ""

    db = re.search(r"Database:\s*(.+)", txt)
    d["Hit_Genome"] = db.group(1).strip() if db else "CEN.PK113-7D (GCA_000269885.1)"

    subj = re.search(r"Sequence ID:\s*([A-Z0-9_.]+)\s+Length:\s*(\d+)", txt)
    if subj:
        d["Hit_Chromosome"] = subj.group(1)
        d["Subject_Length_bp"] = int(subj.group(2))
    else:
        d["Hit_Chromosome"] = ""
        d["Subject_Length_bp"] = ""

    rng = re.search(r"Range 1:\s*(\d+)\s+to\s+(\d+)", txt)
    if rng:
        d["Hit_Start"] = int(rng.group(1))
        d["Hit_End"] = int(rng.group(2))
    else:
        d["Hit_Start"] = ""
        d["Hit_End"] = ""

    ident = re.search(r"Identities:\s*(\d+)/(\d+)\((\d+)%\)", txt)
    if ident:
        d["Identities"] = int(ident.group(1))
        d["Alignment_Length_bp"] = int(ident.group(2))
        d["Identity_Percent_Rounded"] = int(ident.group(3))
        d["Identity_Percent"] = round(100 * int(ident.group(1)) / int(ident.group(2)), 2)
    else:
        d["Identities"] = d["Alignment_Length_bp"] = d["Identity_Percent_Rounded"] = d["Identity_Percent"] = ""

    gaps = re.search(r"Gaps:\s*(\d+)/(\d+)\((\d+)%\)", txt)
    d["Gaps"] = int(gaps.group(1)) if gaps else ""

    strand = re.search(r"Strand:\s*([^\n\r]+)", txt)
    d["Strand"] = strand.group(1).strip() if strand else ""

    return d


def extract_archive(archive: Path, workdir: Path) -> Path:
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(workdir)
    return workdir


def find_files(root: Path, suffix: str) -> list[Path]:
    return sorted(p for p in root.rglob(f"*{suffix}") if "__MACOSX" not in str(p) and p.is_file())


def parse_neb_csv(extracted: Path) -> list[dict]:
    rows = []
    for csv_path in find_files(extracted, ".csv"):
        name = csv_path.name
        if "NEB" not in name and "Tm" not in name:
            continue
        try:
            with csv_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
                reader = csv.DictReader(f)
                for r in reader:
                    # Accept common expected columns from previous project files
                    rows.append({
                        "Source_File": name,
                        "Assay": r.get("assay", r.get("Assay", "")),
                        "Expected_Product_bp": r.get("expected_product_bp", r.get("Expected_Product_bp", "")),
                        "FWD_Label": r.get("primer1_label", r.get("FWD_Label", "")),
                        "FWD_Seq": r.get("primer1_sequence", r.get("FWD_Seq", "")),
                        "REV_Label": r.get("primer2_label", r.get("REV_Label", "")),
                        "REV_Seq": r.get("primer2_sequence", r.get("REV_Seq", "")),
                        "NEB_Anneal_Temp_C": r.get("neb_anneal_c", r.get("NEB_Anneal_Temp_C", "")),
                        "QC_Status": r.get("pass_call", r.get("QC_Status", "")),
                        "Notes": r.get("notes", r.get("Notes", "")),
                    })
        except Exception as e:
            rows.append({
                "Source_File": name,
                "Assay": "PARSE_ERROR",
                "Expected_Product_bp": "",
                "FWD_Label": "",
                "FWD_Seq": "",
                "REV_Label": "",
                "REV_Seq": "",
                "NEB_Anneal_Temp_C": "",
                "QC_Status": "PARSE_ERROR",
                "Notes": str(e),
            })
    return rows


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--archive", default="data_raw/uploaded_archive/Archive.zip")
    ap.add_argument("--out-dir", default="reports")
    args = ap.parse_args()

    archive = Path(args.archive)
    outdir = Path(args.out_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    if not archive.exists():
        raise SystemExit(f"Missing uploaded archive: {archive}")

    extracted = extract_archive(archive, Path("data_intermediate/T00_extracted_archive"))

    blast_files = [p for p in find_files(extracted, ".txt") if "BLAST" in p.name.upper()]
    blast_rows = [parse_blast(p) for p in blast_files]
    write_csv(outdir / "blast_summary.csv", blast_rows)

    primer_rows = parse_neb_csv(extracted)
    write_csv(outdir / "primer_panel_summary.csv", primer_rows)

    evidence = [
        {
            "Claim": "BLAST placement of uploaded left/native/right regions",
            "Status": "PROVEN_FROM_UPLOADED_RECORDS" if blast_rows else "NOT_PROVEN",
            "Reason": f"Parsed {len(blast_rows)} BLAST text files from uploaded archive.",
        },
        {
            "Claim": "NEB/IDT first-pass primer QC records",
            "Status": "PROVEN_FROM_UPLOADED_RECORDS" if primer_rows else "PARTIALLY_SUPPORTED_OR_MISSING",
            "Reason": f"Parsed {len(primer_rows)} primer-QC rows from uploaded archive. This does not prove wet-lab performance.",
        },
        {
            "Claim": "Phase 1 reference/annotation/specificity tests",
            "Status": "NOT_RUN",
            "Reason": "Run T01, T02, and T03 before making Phase 1 claims.",
        },
    ]
    write_csv(outdir / "evidence_status.csv", evidence)

    print(f"T00 Complete.")
    print(f"BLAST rows: {len(blast_rows)} -> {outdir / 'blast_summary.csv'}")
    print(f"Primer rows: {len(primer_rows)} -> {outdir / 'primer_panel_summary.csv'}")


if __name__ == "__main__":
    main()
