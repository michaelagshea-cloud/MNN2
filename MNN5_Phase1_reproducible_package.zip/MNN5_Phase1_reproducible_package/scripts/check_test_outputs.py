#!/usr/bin/env python3
from pathlib import Path
import csv

required = {
    "T00": ["reports/blast_summary.csv", "reports/primer_panel_summary.csv", "reports/evidence_status.csv"],
    "T01": ["reports/T01_reference_checksums.sha256", "reports/T01_status.csv"],
    "T02": ["reports/T02_gff_overlap_check.csv", "reports/T02_orf_boundary_decision.md"],
    "T03": ["reports/T03_primer_specificity_summary.csv", "reports/T03_in_silico_pcr_hits.csv"],
}
Path("reports").mkdir(exist_ok=True)
with open("reports/test_completion_matrix.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["test_id", "status", "missing_outputs", "required_outputs"])
    for test_id, files in required.items():
        missing = [p for p in files if not Path(p).exists()]
        status = "OUTPUTS_PRESENT_REVIEW_REQUIRED" if not missing else "MISSING_OUTPUTS"
        w.writerow([test_id, status, ";".join(missing), ";".join(files)])
print("Wrote reports/test_completion_matrix.csv")
