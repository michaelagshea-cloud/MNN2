#!/usr/bin/env bash
set -euo pipefail

mkdir -p data_raw/reference reports logs

if ! command -v datasets >/dev/null 2>&1; then
  echo "ERROR: NCBI Datasets CLI is not installed or not on PATH." >&2
  echo "Install it first, then rerun this script." >&2
  exit 127
fi

if ! command -v unzip >/dev/null 2>&1; then
  echo "ERROR: unzip is not installed or not on PATH." >&2
  exit 127
fi

echo "T01: Downloading CEN.PK113-7D reference accession GCA_000269885.1"
datasets download genome accession GCA_000269885.1 \
  --include genome,gff3,gbff,seq-report \
  --filename data_raw/reference/GCA_000269885.1_CENPK1137D_dataset.zip \
  2>&1 | tee logs/T01_download_reference.log

echo "T01: Unzipping reference data"
unzip -o data_raw/reference/GCA_000269885.1_CENPK1137D_dataset.zip \
  -d data_raw/reference/GCA_000269885.1_CENPK1137D_dataset \
  2>&1 | tee -a logs/T01_download_reference.log

echo "T01: Locating FASTA/GFF/GBFF/metadata files"
find data_raw/reference -type f \
  \( -name "*.fna" -o -name "*.fa" -o -name "*.fasta" -o -name "*.gff" -o -name "*.gff3" -o -name "*.gbff" -o -name "*.jsonl" \) \
  | sort > reports/T01_reference_file_list.txt

FASTA_COUNT=$(grep -E '\.(fna|fa|fasta)$' reports/T01_reference_file_list.txt | wc -l | tr -d ' ')
GFF_COUNT=$(grep -E '\.(gff|gff3)$' reports/T01_reference_file_list.txt | wc -l | tr -d ' ')

if [ "$FASTA_COUNT" -lt 1 ]; then
  echo "ERROR: No FASTA file found after download." >&2
  exit 1
fi

if [ "$GFF_COUNT" -lt 1 ]; then
  echo "ERROR: No GFF/GFF3 file found after download." >&2
  exit 1
fi

echo "T01: Generating SHA256 checksums"
find data_raw/reference -type f \
  \( -name "*.zip" -o -name "*.fna" -o -name "*.fa" -o -name "*.fasta" -o -name "*.gff" -o -name "*.gff3" -o -name "*.gbff" -o -name "*.jsonl" \) \
  -exec sha256sum {} \; | sort > reports/T01_reference_checksums.sha256

cat > reports/T01_status.csv <<EOF
test_id,status,detail
T01,PASS,Reference download produced at least one FASTA and at least one GFF/GFF3; checksums recorded.
EOF

echo "T01 Complete."
echo "Files: reports/T01_reference_file_list.txt, reports/T01_reference_checksums.sha256, reports/T01_status.csv"
