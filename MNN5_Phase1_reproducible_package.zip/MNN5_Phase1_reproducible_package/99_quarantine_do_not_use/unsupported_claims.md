# QUARANTINE FILE: DO NOT CITE

The following claims are not allowed unless supported by raw input, exact command/script, software/version basis, raw output, parsed summary, checksum, and pass/fail status.

Forbidden:
- ALL TESTS PASS
- computationally verified
- AlphaGenome confirmed
- no off-targets
- MNN5 edit verified
- full MNN5 ORF deleted
- FBA confirms viability
- protein loss-of-function confirmed
- wet-lab validated
- P39107 is MNN5

Reason:
These claims are not established by Phase 1. Phase 1 only addresses reference traceability, annotation overlap, and in silico primer specificity.
