# Phase 1 workflow

```mermaid
flowchart TD
    A[Archive.zip uploaded BLAST/primer QC] --> T00[T00 audit archive]
    T00 --> B[blast_summary.csv + primer_panel_summary.csv]
    C[NCBI GCA_000269885.1] --> T01[T01 download reference]
    T01 --> D[FASTA + GFF/GFF3 + checksums]
    B --> T02[T02 GFF overlap classification]
    D --> T02
    D --> T03[T03 in silico PCR specificity]
    E[primer_pairs.tsv] --> T03
    T02 --> F[ORF-boundary decision]
    T03 --> G[primer specificity summary]
```
