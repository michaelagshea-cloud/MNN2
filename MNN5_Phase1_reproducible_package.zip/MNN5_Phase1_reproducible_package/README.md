# MNN5 Phase 1 Reproducible Package

Created: 2026-05-31

## Status

This ZIP is a **runnable Phase 1 package**, not proof that Phase 1 has already passed.

Current included evidence:
- Uploaded archive copied to `data_raw/uploaded_archive/Archive.zip` if it was available.
- Primer configuration for four MNN5 assay panels.
- Scripts T00-T03.
- Traceability templates.

A scientific conclusion is allowed only after the scripts generate output files.

## What Phase 1 tests

- **T00**: parse uploaded BLAST/primer-QC archive.
- **T01**: download and checksum CEN.PK113-7D `GCA_000269885.1` reference FASTA and GFF/GFF3.
- **T02**: classify BLAST intervals relative to MNN5/YJL186W annotation.
- **T03**: run genome-wide in silico PCR specificity against the exact downloaded FASTA.

## How to run

From inside this folder:

```bash
chmod +x scripts/T01_download_reference.sh scripts/run_phase1_foundation_tests.sh
bash scripts/run_phase1_foundation_tests.sh
```

Then print the critical outputs:

```bash
cat reports/T02_orf_boundary_decision.md
cat reports/T03_primer_specificity_summary.csv
```

## Required outputs before any Phase 1 claim

```text
reports/blast_summary.csv
reports/primer_panel_summary.csv
reports/T01_reference_checksums.sha256
reports/T01_status.csv
reports/T02_gff_overlap_check.csv
reports/T02_orf_boundary_decision.md
reports/T03_primer_specificity_summary.csv
reports/T03_in_silico_pcr_hits.csv
reports/test_completion_matrix.csv
MANIFEST.sha256
```

## Allowed wording before running

The repository contains traceable first-pass primer QC and BLAST placement evidence. Phase 1 reference, annotation-overlap, and genome-wide primer-specificity tests remain pending.

## Allowed wording only after successful run

The uploaded MNN5-region assay sequences were evaluated against the CEN.PK113-7D GCA_000269885.1 reference genome. GFF/GFF3 annotation overlap was used to classify the 725 bp native/internal assay segment relative to MNN5/YJL186W, and genome-wide in silico PCR was used to screen primer specificity under a maximum three-mismatch setting.
