# Rerun Instructions

This package was generated from the uploaded MNN5 local evidence ZIPs and available edited genome FASTA.

To fully reproduce externally, keep the input ZIPs in `inputs/` and rerun a local audit script that:
1. extracts FASTA/CSV/GFF3 records,
2. recomputes sequence lengths, codons, primer properties, and checksums,
3. writes the same report tables.

This generated package includes all outputs and a SHA256 manifest.
