# MNN5 Pre-Wet-Lab Computational Test Package

This package separates the MNN5 pre-wet-lab checks into individual report files.

## Strict result

Current overall status:

`NOT_READY_FOR_WET_LAB_ORDER_UNDER_STRICT_STANDARD`

The MNN5 in-silico sequence model is supported by the uploaded files, but this package does not make wet-lab, primer order-readiness, additional safety-screening, FBA, protein-structure, toxicity, or phenotype claims.

## What was actually run locally

- Sequence coordinate/model assertions.
- CDS translation and ORF check.
- Basic codon composition and codon-count report.
- Basic primer length/GC/approximate Wallace Tm screen.
- Exact-match primer amplicon screen against available edited genome/cassette contexts.
- Simple self-complementarity screen for primers.
- Exact 20-mer construct screen against available edited genome.

## What was not truthfully runnable from the current uploaded files

- True thermodynamic ΔG folding calculations.
- ODE kinetic pathway simulations.
- Gillespie stochastic simulations.
- FBA/MFA.
- AlphaFold.
- Molecular dynamics.
- Quantum mechanical calculations.
- Free energy perturbation.
- Host toxicity/stress prediction.
- Full Primer-BLAST or full host-wide off-target/safety-screening.

These require external tools and/or missing biological parameters.
