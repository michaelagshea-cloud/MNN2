# Unsupported Claims — Do Not Cite

The current MNN5 package does not support these claims:

- wet-lab validated
- edit experimentally confirmed
- all tests pass
- primers order-ready
- no additional safety-screening concerns
- FBA viability confirmed
- thermodynamic ΔG folding cleared
- ODE/stochastic model validated
- AlphaFold/MD/QM/FEP completed
- host toxicity cleared
- phenotype/EV effect confirmed
- complete publication-level validation
