# MNN5 expected amplicon logic — first-pass, not validated

This file describes intended assay logic. It is **not** a specificity result.

## MNN5_5prime_true_integration_junction_FIRSTPASS

- Intended WT/unedited CP022975.1 result: no product, because the optimized-CDS reverse primer target should be absent.
- Intended donor/cassette-only result: no product, because the outside-left-genome forward primer should be outside the donor homology arm.
- Intended edited-genome result: ~806 bp product.
- Current status: FIRSTPASS_NOT_ORDER_READY_REQUIRES_LOCAL_SPECIFICITY_AND_PRIMER_BLAST.

## MNN5_3prime_true_integration_junction_FIRSTPASS

- Intended WT/unedited CP022975.1 result: no product, because the optimized-CDS forward primer target should be absent.
- Intended donor/cassette-only result: no product, because the outside-right-genome reverse primer should be outside the donor homology arm.
- Intended edited-genome result: ~801 bp product.
- Current status: FIRSTPASS_NOT_ORDER_READY_REQUIRES_LOCAL_SPECIFICITY_AND_PRIMER_BLAST.

## MNN5_native_ORF_loss_SUPPORT

- Intended WT/unedited result: 725 bp product.
- Intended edited result: no product.
- Current status: support assay; still needs local specificity confirmation.

## MNN5_insert_internal_SUPPORT

- Intended WT/unedited result: no product.
- Intended donor/cassette-only result: 682 bp product.
- Intended edited-genome result: 682 bp product.
- Current status: support only; not locus-specific and not chromosomal integration proof.
