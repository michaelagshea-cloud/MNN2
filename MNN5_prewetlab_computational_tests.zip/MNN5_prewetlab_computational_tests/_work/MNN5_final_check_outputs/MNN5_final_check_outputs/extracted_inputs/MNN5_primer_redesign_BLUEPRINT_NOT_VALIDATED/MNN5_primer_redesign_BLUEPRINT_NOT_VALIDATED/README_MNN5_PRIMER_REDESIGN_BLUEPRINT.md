# MNN5 primer redesign blueprint — NOT VALIDATED

This package contains MNN5-only first-pass primer redesign information.

It corrects the previous overclaim by labeling the new junction assays as:
`NOT_RUN_PENDING_LOCAL_IN_SILICO_PCR`

The package includes candidate outside-arm junction primers from the uploaded MNN5 Primer3 guide, but it does not claim they are order-ready.

## Next required test

Run `MNN5_redesigned_primer_pairs_for_T03.tsv` through local in-silico PCR against:

1. unedited CP022975.1 reference,
2. CP022975.1 edited MNN5 model,
3. donor/cassette-only sequence.

Only after that can a junction assay be labeled as a true chromosomal integration support assay.

## Current safest claim

The MNN5 Primer3 guide provides first-pass outside-arm junction primer candidates. Their intended design logic would avoid donor-only amplification if the outside-arm primer targets are truly outside the donor homology arms, but this remains unvalidated until local specificity testing is run.
