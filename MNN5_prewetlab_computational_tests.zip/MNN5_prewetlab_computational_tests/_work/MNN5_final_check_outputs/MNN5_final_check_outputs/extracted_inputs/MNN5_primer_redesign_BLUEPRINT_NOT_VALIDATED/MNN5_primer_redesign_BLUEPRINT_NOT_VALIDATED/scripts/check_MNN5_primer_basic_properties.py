#!/usr/bin/env python3
"""
Check primer panel formatting and basic primer properties.
This does not replace genome-wide specificity testing.
"""
from pathlib import Path
import csv

def gc(seq):
    return 100 * sum(1 for b in seq.upper() if b in "GC") / len(seq)

inp = Path("primer_panels/MNN5_redesigned_primer_panel_FIRSTPASS_NOT_ORDER_READY.csv")
out = Path("reports/MNN5_primer_basic_properties.csv")
with inp.open() as f, out.open("w", newline="") as g:
    r = csv.DictReader(f)
    fields = ["assay","primer","sequence","length_nt","gc_percent","basic_status"]
    w = csv.DictWriter(g, fieldnames=fields)
    w.writeheader()
    for row in r:
        for side, col in [("forward","forward_sequence_5to3"),("reverse","reverse_sequence_5to3")]:
            seq = row[col].strip().upper()
            status = "PASS_BASIC_LENGTH_GC" if 18 <= len(seq) <= 25 and 35 <= gc(seq) <= 65 else "REVIEW_BASIC_PROPERTIES"
            w.writerow({
                "assay": row["assay"],
                "primer": side,
                "sequence": seq,
                "length_nt": len(seq),
                "gc_percent": round(gc(seq), 2),
                "basic_status": status,
            })
print(f"Wrote {out}")
