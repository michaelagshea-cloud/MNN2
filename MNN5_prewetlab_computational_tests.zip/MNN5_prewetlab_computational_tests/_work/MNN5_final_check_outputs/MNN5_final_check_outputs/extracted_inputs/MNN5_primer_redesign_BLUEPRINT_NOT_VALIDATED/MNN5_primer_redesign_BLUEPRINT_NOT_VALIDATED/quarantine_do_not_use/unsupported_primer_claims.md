# Unsupported primer claims — do not cite

Do not claim:
- primers order-ready
- PASS_TRUE_CHROMOSOMAL_JUNCTION_ASSAY
- edit experimentally confirmed
- all tests pass
- no off-targets
- donor/cassette band proves integration
- insert-internal PCR proves locus-specific integration
