# MNN5 primer redesign red flags

- The earlier agent output incorrectly labeled proposed junction assays as `PASS_TRUE_CHROMOSOMAL_JUNCTION_ASSAY` without running specificity tests.
- These primers are first-pass candidates, not order-ready primers.
- A true junction assay must be tested against three contexts: unedited CP022975.1, edited CP022975.1, and donor/cassette-only.
- Donor/cassette-only amplification is not chromosomal integration proof.
- The insert-internal assay is support only and cannot distinguish donor/cassette presence from integrated chromosomal sequence.
- Do not claim wet-lab edit validation without PCR/Sanger/amplicon/WGS evidence.
