# MNN5 Primer Interpretation Summary

- **left_junction**: REVIEW_JUNCTION_PRODUCT_PRESENT_IN_DONOR_OR_CASSETTE_CONTEXT. Not a standalone chromosomal integration proof; use with caution.
- **right_junction**: REVIEW_JUNCTION_NOT_UNEDITED_SPECIFIC. Redesign may be needed for true integration proof; can keep only as support/cassette-boundary-like assay until resolved.
- **insert_internal**: LOCAL_PCR_SUPPORTS_INSERT_PRESENCE_ASSAY. Support assay only; not locus-specific by itself.
- **native_ORF_loss**: LOCAL_PCR_SUPPORTS_NATIVE_ORF_LOSS_ASSAY. Expected WT/native positive and edited negative pattern. Strongest support assay for loss of native sequence.
