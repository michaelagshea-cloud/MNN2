# MNN5 red flags

- Do not interpret the 2434 bp MNN5 edited locus cassette as an ORF. It contains 500 bp left genomic arm + 1434 bp optimized CDS + 500 bp right genomic arm, so internal stop codons in the full cassette are expected and irrelevant. ORF validation applies only to the 1434 bp optimized CDS record.
- Do not mix older CM001531.1/GCA_000269885.1 coordinate claims with CP022975.1 unless explicitly mapped.
- Do not claim wet-lab validation from in-silico FASTA/GFF/manifest files.
- Do not treat junction primers as standalone integration proof if local PCR interpretation flags donor/cassette or unedited-context products.
- Do not claim off-target safety unless gRNA/primer off-target outputs exist.
