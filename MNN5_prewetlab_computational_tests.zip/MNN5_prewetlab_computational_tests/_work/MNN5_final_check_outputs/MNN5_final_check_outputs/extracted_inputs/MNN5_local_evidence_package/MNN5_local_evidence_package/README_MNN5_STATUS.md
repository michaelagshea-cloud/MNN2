# MNN5 Local Evidence Package

This local package summarizes the current uploaded MNN5/YJL186W in-silico evidence.

Supported: CP022975.1-based in-silico MNN5/YJL186W replacement model.

Not supported by this package: wet-lab validation, experimental edit confirmation, off-target clearance, primer order-readiness, FBA viability, protein function, or phenotype/EV claims.
