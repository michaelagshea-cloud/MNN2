# MNN5 file review — what is still needed

Generated: 2026-05-31

## What is now present

- Left 500 bp CP022975.1 genomic-forward arm as raw text/FASTA.
- Right 500 bp CP022975.1 genomic-forward arm as raw text/FASTA.
- Benchling 500 bp arms + optimized CDS review-only construct PDF. A 2434 bp top-strand sequence was extracted from the PDF.
- The extracted review construct starts with the left 500 bp arm and ends with the right 500 bp arm.
- The internal sequence inferred from the combined construct is 1434 bp.
- The inferred internal optimized CDS has an ATG start, terminal stop codon, no internal stops, and is divisible by 3.
- The MNN5/YJL186W mRNA/genomic annotation view is present as a Benchling PDF and yielded a 2761 bp viewed sequence extraction.

## Important review flags

1. The standalone optimized-CDS PDF extraction produced 1391 bp, while the internal sequence inferred from the combined donor construct is 1434 bp. The combined construct contains 43 additional bp beyond the standalone PDF extraction. This means the standalone PDF extraction should be treated as partial/truncated unless a raw FASTA/GenBank confirms otherwise.

2. The combined construct filename says `REVIEW_ONLY`, so do not treat it as final order-ready donor sequence unless you confirm that this is the final donor.

3. The newer files use CP022975.1 / MNN5 feature around 80155-81915, while older audit text referenced CM001531.1:62896-63620. Those coordinate systems must not be mixed without an accession mapping.

## What I still need, if you want a fully final repository

1. A confirmation sentence:
   `Use CP022975.1 / MNN5 80155-81915 as the current authoritative MNN5 coordinate system.`

2. Confirmation that:
   `MNN5_YJL186W_CENPK113-7D_500bpArms_optimizedCDS_REVIEW_ONLY_ONE_LINE` is the final donor design, despite the REVIEW_ONLY label.
   Or upload/export the final GenBank.

3. If available, a raw GenBank export from Benchling for the combined donor, because PDF extraction is not ideal for final computational provenance.

4. Phase 1 run outputs if you want to cite the reference/GFF/specificity tests as completed.
