# Visual workflow model

```mermaid
flowchart TD
    A[Uploaded Archive.zip] --> B[Parse BLAST reports]
    A --> C[Parse NEB/IDT primer QC]
    B --> D[BLAST placement evidence]
    C --> E[First-pass primer QC evidence]
    D --> F{Reference FASTA + GFF3 present?}
    F -- No --> G[NOT_RUN: ORF boundary and specificity checks]
    F -- Yes --> H[Run GFF overlap and in-silico PCR]
    H --> I{Donor/insert sequence present?}
    I -- No --> J[NOT_PROVEN: insert identity/edit-aware junction]
    I -- Yes --> K[Build edit-aware reference and synthetic FASTQ]
    K --> L[Pipeline sensitivity/specificity]
    M[yeast-GEM model + constraints] --> N[FBA / OptKnock]
    O[Circuit model parameters] --> P[Boolean/ODE/stochastic checks]
    Q[Protein structure + ligand] --> R[MD/docking/mutagenesis]
```
