# MNN5 CEN.PK113-7D reproducible test harness

## Direct answer

The prior agent did **not** successfully run the full requested test suite. The only completed checks in this package are:

- Parsing uploaded BLAST reports into `reports/blast_summary.csv`.
- Parsing uploaded NEB primer panel information into `reports/primer_panel_summary.csv`.
- Recording an evidence matrix that marks missing tests as `NOT_RUN`, `NOT_PROVEN`, or `REQUIRES_WET_LAB`.

No FBA, OptKnock, thermodynamic feasibility, circuit modeling, molecular dynamics, docking, off-target scoring, codon optimization, sequence homology screening, synthetic FASTQ validation, or sensitivity/specificity analysis has been completed from the uploaded archive alone.

## Why not?

Those tests require raw inputs that are not present in `Archive.zip`: exact CEN.PK113-7D FASTA/GFF3, full insert/donor sequence, guide RNA list, yeast-GEM model file, model constraints, circuit parameters, protein structures, ligand files, local BLAST databases, and/or wet-lab validation files.

## Current reproducible evidence

- `reports/blast_summary.csv` proves only that the uploaded BLAST reports contain placements against the CEN.PK113-7D reference named in those reports.
- `reports/primer_panel_summary.csv` proves only that uploaded NEB/IDT first-pass primer QC records exist.
- `reports/test_completion_matrix.csv` lists whether each requested test was actually run.

## Run available local audit

```bash
python scripts/run_all_available_tests.py
```

## Download the CEN.PK113-7D reference

```bash
bash scripts/01_download_reference.sh
```

Then run GFF overlap checks:

```bash
python scripts/02_verify_gff_overlap.py   --gff3 path/to/genomic.gff   --blast-summary reports/blast_summary.csv   --out reports/gff_overlap_check.csv
```

## Fail-closed rule

A test may only be marked `COMPLETE` if the raw input, exact command/script, software version, and raw output are present. Missing tests must be reported as `NOT_RUN` or `NOT_PROVEN`.
