#!/usr/bin/env python3
"""Calculate sensitivity/specificity from a truth table and detector calls.
truth CSV: sample_id,true_label (1/0). calls CSV: sample_id,pred_label (1/0).
"""
import argparse, csv
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--truth', required=True); ap.add_argument('--calls', required=True); ap.add_argument('--out', default='reports/sensitivity_specificity.csv'); args=ap.parse_args()
    if not Path(args.truth).exists() or not Path(args.calls).exists():
        Path(args.out).write_text('status,reason\nNOT_RUN_MISSING_INPUT,Provide truth and calls CSV files\n'); return
    truth={r['sample_id']:int(r['true_label']) for r in csv.DictReader(open(args.truth))}
    calls={r['sample_id']:int(r['pred_label']) for r in csv.DictReader(open(args.calls))}
    tp=tn=fp=fn=0
    for sid,t in truth.items():
        p=calls.get(sid)
        if p is None: continue
        if t==1 and p==1: tp+=1
        elif t==0 and p==0: tn+=1
        elif t==0 and p==1: fp+=1
        elif t==1 and p==0: fn+=1
    sens=tp/(tp+fn) if tp+fn else ''
    spec=tn/(tn+fp) if tn+fp else ''
    with open(args.out,'w',newline='') as f:
        w=csv.writer(f); w.writerow(['tp','tn','fp','fn','sensitivity','specificity']); w.writerow([tp,tn,fp,fn,sens,spec])
if __name__ == '__main__': main()
