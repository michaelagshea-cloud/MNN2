#!/usr/bin/env bash
set -euo pipefail
mkdir -p 00_reference
# Requires NCBI Datasets CLI: https://www.ncbi.nlm.nih.gov/datasets/docs/v2/download-and-install/
datasets download genome accession GCA_000269885.1 \
  --include genome,gff3,gbff,seq-report \
  --filename 00_reference/GCA_000269885.1_CENPK1137D_dataset.zip
unzip -o 00_reference/GCA_000269885.1_CENPK1137D_dataset.zip \
  -d 00_reference/GCA_000269885.1_CENPK1137D_dataset
find 00_reference -type f \( -name "*.fna" -o -name "*.gff" -o -name "*.gff3" -o -name "*.gbff" -o -name "*.jsonl" \) \
  -exec sha256sum {} \; > 00_reference/checksums.sha256
