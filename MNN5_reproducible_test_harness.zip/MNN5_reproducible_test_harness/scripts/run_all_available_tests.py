#!/usr/bin/env python3
"""Run only tests with available inputs. Missing-input tests are recorded as NOT_RUN, never fabricated."""
import csv, json, subprocess, sys
from pathlib import Path

commands = [
    ['python','scripts/00_audit_uploaded_archive.py','--archive','data_raw/uploaded_archive/Archive.zip','--out','reports'],
]
results=[]
for cmd in commands:
    try:
        r=subprocess.run(cmd, capture_output=True, text=True, check=False)
        results.append({'command':' '.join(cmd),'returncode':r.returncode,'stdout':r.stdout.strip(),'stderr':r.stderr.strip()})
    except Exception as e:
        results.append({'command':' '.join(cmd),'returncode':'ERROR','stdout':'','stderr':str(e)})
Path('reports').mkdir(exist_ok=True)
Path('reports/run_log.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
