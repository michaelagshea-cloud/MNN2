#!/usr/bin/env python3
"""Simple in-silico PCR / primer specificity scanner.
Inputs: FASTA reference + primer CSV. Reports candidate amplicons up to max_product.
This is a screening tool, not wet-lab proof.
"""
import argparse, csv
from pathlib import Path

def read_fasta(path):
    seqs={}; name=None; chunks=[]
    for line in open(path):
        line=line.strip()
        if not line: continue
        if line.startswith('>'):
            if name: seqs[name]=''.join(chunks).upper()
            name=line[1:].split()[0]; chunks=[]
        else: chunks.append(line)
    if name: seqs[name]=''.join(chunks).upper()
    return seqs

def rc(s):
    return s.translate(str.maketrans('ACGTNacgtn','TGCANtgcan'))[::-1].upper()

def mismatches(a,b):
    return sum(x!=y for x,y in zip(a.upper(), b.upper()))

def find_sites(seq, primer, max_mm):
    L=len(primer); out=[]
    for i in range(0, len(seq)-L+1):
        mm=mismatches(seq[i:i+L], primer)
        if mm<=max_mm: out.append((i+1, '+', mm))
        mm=mismatches(seq[i:i+L], rc(primer))
        if mm<=max_mm: out.append((i+1, '-', mm))
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--fasta', required=True)
    ap.add_argument('--primers', default='reports/primer_panel_summary.csv')
    ap.add_argument('--max-mismatches', type=int, default=3)
    ap.add_argument('--max-product', type=int, default=3000)
    ap.add_argument('--out', default='reports/in_silico_pcr_hits.csv')
    args=ap.parse_args()
    seqs=read_fasta(args.fasta)
    rows=[]
    with open(args.primers, newline='') as f:
        for r in csv.DictReader(f):
            assay=r.get('assay','')
            fwd=r.get('primer1_sequence') or r.get('primer1_sequence'.upper()) or r.get('primer1')
            rev=r.get('primer2_sequence') or r.get('primer2')
            if not fwd or not rev: continue
            for chrom, seq in seqs.items():
                fs=find_sites(seq, fwd, args.max_mismatches)
                rs=find_sites(seq, rev, args.max_mismatches)
                for fp,fsign,fmm in fs:
                    for rp,rsign,rmm in rs:
                        if fsign=='+' and rsign=='-' and fp < rp:
                            size = rp + len(rev) - fp
                            if size <= args.max_product:
                                rows.append({'assay':assay,'chrom':chrom,'start':fp,'end':rp+len(rev)-1,'product_bp':size,'fwd_mm':fmm,'rev_mm':rmm})
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out,'w',newline='') as f:
        fields=['assay','chrom','start','end','product_bp','fwd_mm','rev_mm']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'Wrote {len(rows)} candidate amplicons to {args.out}')

if __name__ == '__main__': main()
