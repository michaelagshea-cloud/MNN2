#!/usr/bin/env bash
set -euo pipefail
# This is a local compliance/homology screen wrapper. It does not bypass safety screening.
# Required inputs:
#   QUERY_FASTA: designed sequence FASTA
#   BLAST_DB: local, named, versioned BLAST database path
# Example:
#   QUERY_FASTA=insert.fasta BLAST_DB=/db/nt_2026_05 blastn ...
: "${QUERY_FASTA:?Set QUERY_FASTA to a FASTA file}"
: "${BLAST_DB:?Set BLAST_DB to a local BLAST database}"
mkdir -p reports
blastn -query "$QUERY_FASTA" -db "$BLAST_DB" -out reports/homology_screen.tsv \
  -outfmt '6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore stitle' \
  -max_target_seqs 50
