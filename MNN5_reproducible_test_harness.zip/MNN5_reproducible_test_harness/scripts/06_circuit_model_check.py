#!/usr/bin/env python3
"""Minimal fail-closed Boolean/ODE circuit checker.
Requires a YAML file with boolean_rules and/or ode_parameters. Does not invent circuit parameters.
"""
import argparse, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config', required=True); ap.add_argument('--out', default='reports/circuit_check.json'); args=ap.parse_args()
    try: import yaml
    except Exception as e:
        Path(args.out).write_text(json.dumps({'status':'NOT_RUN_MISSING_DEPENDENCY','reason':str(e)}, indent=2)); return
    if not Path(args.config).exists():
        Path(args.out).write_text(json.dumps({'status':'NOT_RUN_MISSING_CIRCUIT_CONFIG','reason':args.config}, indent=2)); return
    cfg=yaml.safe_load(Path(args.config).read_text()) or {}
    result={'status':'COMPLETE_WITH_LIMITS','boolean_rules_present':bool(cfg.get('boolean_rules')),'ode_parameters_present':bool(cfg.get('ode_parameters')),'note':'This only confirms model specification presence unless equations/parameters are supplied.'}
    if not result['boolean_rules_present'] and not result['ode_parameters_present']:
        result['status']='NOT_RUN_NO_MODEL_DEFINED'
    Path(args.out).write_text(json.dumps(result, indent=2))
if __name__ == '__main__': main()
