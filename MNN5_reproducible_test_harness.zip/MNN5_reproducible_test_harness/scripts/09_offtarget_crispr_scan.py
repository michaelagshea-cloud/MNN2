#!/usr/bin/env python3
"""Scan a reference FASTA for guide+PAM exact/near matches. User supplies guide list; this script does not design guides.
Inputs: guides CSV fields guide_id,spacer,pam_regex (e.g. NGG). Use only for benign organisms and local compliance screening.
"""
import argparse, csv, re
from pathlib import Path

def read_fasta(path):
    seqs={}; name=None; chunks=[]
    for line in open(path):
        line=line.strip()
        if not line: continue
        if line.startswith('>'):
            if name: seqs[name]=''.join(chunks).upper()
            name=line[1:].split()[0]; chunks=[]
        else: chunks.append(line)
    if name: seqs[name]=''.join(chunks).upper()
    return seqs

def rc(s): return s.translate(str.maketrans('ACGTN','TGCAN'))[::-1]
def mm(a,b): return sum(x!=y for x,y in zip(a,b))
def pam_to_re(pam): return pam.upper().replace('N','[ACGT]')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--fasta', required=True); ap.add_argument('--guides-csv', required=True); ap.add_argument('--max-mismatches', type=int, default=3); ap.add_argument('--out', default='reports/offtarget_scan.csv'); args=ap.parse_args()
    if not Path(args.fasta).exists() or not Path(args.guides_csv).exists():
        Path(args.out).write_text('status,reason\nNOT_RUN_MISSING_INPUT,Provide reference FASTA and guides CSV\n'); return
    seqs=read_fasta(args.fasta); rows=[]
    with open(args.guides_csv,newline='') as f:
        for g in csv.DictReader(f):
            spacer=g['spacer'].upper(); pam_re=pam_to_re(g.get('pam_regex','NGG')); L=len(spacer)
            for chrom,seq in seqs.items():
                for i in range(0,len(seq)-L-3+1):
                    protospacer=seq[i:i+L]; pam=seq[i+L:i+L+3]
                    mism=mm(protospacer, spacer)
                    if mism <= args.max_mismatches and re.fullmatch(pam_re, pam):
                        rows.append({'guide_id':g.get('guide_id',''),'chrom':chrom,'start':i+1,'end':i+L+3,'strand':'+','mismatches':mism,'pam':pam})
                    window=rc(seq[i:i+L+3]); protospacer=window[:L]; pam=window[L:L+3]
                    mism=mm(protospacer, spacer)
                    if mism <= args.max_mismatches and re.fullmatch(pam_re,pam):
                        rows.append({'guide_id':g.get('guide_id',''),'chrom':chrom,'start':i+1,'end':i+L+3,'strand':'-','mismatches':mism,'pam':pam})
    with open(args.out,'w',newline='') as f:
        fields=['guide_id','chrom','start','end','strand','mismatches','pam']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'Wrote {len(rows)} candidate guide+PAM hits to {args.out}')
if __name__ == '__main__': main()
