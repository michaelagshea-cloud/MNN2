#!/usr/bin/env python3
"""Generate synthetic FASTQ reads from a supplied edit-aware reference.
This tests a bioinformatics pipeline only; it does not validate a real strain.
"""
import argparse, random
from pathlib import Path

def read_seq(p):
    return ''.join(l.strip().upper() for l in open(p) if not l.startswith('>'))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--reference-fasta', required=True); ap.add_argument('--start', type=int, required=True); ap.add_argument('--end', type=int, required=True); ap.add_argument('--read-len', type=int, default=150); ap.add_argument('--coverage', type=int, default=20); ap.add_argument('--out', default='reports/synthetic_reads.fastq'); args=ap.parse_args()
    if not Path(args.reference_fasta).exists():
        Path(args.out).write_text('') ; print('NOT_RUN_MISSING_REFERENCE'); return
    seq=read_seq(args.reference_fasta); region=seq[args.start-1:args.end]
    random.seed(1)
    with open(args.out,'w') as f:
        for i in range(args.coverage):
            if len(region) < args.read_len: read=region
            else: 
                s=random.randint(0,len(region)-args.read_len); read=region[s:s+args.read_len]
            f.write(f'@synthetic_{i}\n{read}\n+\n{"I"*len(read)}\n')
    print(f'Wrote synthetic FASTQ to {args.out}. Pipeline test only, not biological validation.')
if __name__ == '__main__': main()
