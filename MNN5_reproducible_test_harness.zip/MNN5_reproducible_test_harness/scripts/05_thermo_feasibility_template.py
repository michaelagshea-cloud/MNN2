#!/usr/bin/env python3
"""Flag pathway reactions as thermodynamically favorable/unfavorable from supplied delta-G data.
Input CSV fields: reaction_id,delta_g_kj_per_mol,source,condition_notes
"""
import argparse, csv
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dg-csv', required=True)
    ap.add_argument('--out', default='reports/thermo_feasibility.csv')
    args=ap.parse_args()
    if not Path(args.dg_csv).exists():
        Path(args.out).write_text('status,reason\nNOT_RUN_MISSING_DG_CSV,Input delta-G CSV not found\n'); return
    rows=[]
    with open(args.dg_csv, newline='') as f:
        for r in csv.DictReader(f):
            dg=float(r['delta_g_kj_per_mol'])
            rows.append({**r, 'feasibility_call':'FORWARD_FAVORABLE' if dg < 0 else 'NOT_FORWARD_FAVORABLE'})
    with open(args.out,'w',newline='') as f:
        fields=list(rows[0].keys()) if rows else ['status']
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'Wrote {len(rows)} thermodynamic rows to {args.out}')
if __name__ == '__main__': main()
