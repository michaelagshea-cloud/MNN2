#!/usr/bin/env python3
"""Length-based resource/burden calculation from explicit user-supplied assumptions only.
Requires CDS FASTA and config JSON/YAML with copy_number, transcripts_per_cell, protein_half_life_min, etc.
"""
import argparse, json
from pathlib import Path

def read_fasta_len(p):
    seq=''.join(line.strip() for line in open(p) if not line.startswith('>'))
    return len(seq), len(seq)//3

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--cds-fasta', required=True); ap.add_argument('--config', required=True); ap.add_argument('--out', default='reports/resource_burden.json'); args=ap.parse_args()
    if not Path(args.cds_fasta).exists() or not Path(args.config).exists():
        Path(args.out).write_text(json.dumps({'status':'NOT_RUN_MISSING_INPUT','required':['cds_fasta','config']}, indent=2)); return
    cfg=json.loads(Path(args.config).read_text())
    nt, aa=read_fasta_len(args.cds_fasta)
    copy=float(cfg['copy_number']); tx=float(cfg['transcripts_per_cell'])
    aa_polymerizations = aa * copy * tx
    result={'status':'COMPLETE_ASSUMPTION_BASED','cds_nt':nt,'protein_aa':aa,'copy_number':copy,'transcripts_per_cell':tx,'aa_polymerizations_per_cell_estimate':aa_polymerizations,'warning':'Assumption-based only; not toxicity proof.'}
    Path(args.out).write_text(json.dumps(result, indent=2))
if __name__ == '__main__': main()
