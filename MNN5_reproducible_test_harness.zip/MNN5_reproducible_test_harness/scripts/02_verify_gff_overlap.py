#!/usr/bin/env python3
"""Check whether BLAST intervals overlap annotated features in a GFF3 file.
Does not assume that a BLAST interval equals a full gene unless annotation proves it.
"""
import argparse, csv, re
from pathlib import Path

def attrs_to_dict(s):
    out={}
    for part in s.split(';'):
        if '=' in part:
            k,v=part.split('=',1); out[k]=v
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--gff3', required=True)
    ap.add_argument('--blast-summary', default='reports/blast_summary.csv')
    ap.add_argument('--out', default='reports/gff_overlap_check.csv')
    args=ap.parse_args()
    intervals=[]
    with open(args.blast_summary, newline='') as f:
        for r in csv.DictReader(f):
            if r.get('subject_accession') and r.get('hit_start') and r.get('hit_end'):
                intervals.append(r)
    rows=[]
    with open(args.gff3, errors='replace') as f:
        for line in f:
            if not line.strip() or line.startswith('#'): continue
            parts=line.rstrip('\n').split('\t')
            if len(parts)<9: continue
            seqid, source, ftype, start, end, score, strand, phase, attrs=parts[:9]
            try: start=int(start); end=int(end)
            except ValueError: continue
            for iv in intervals:
                if seqid == iv['subject_accession'] and start <= int(iv['hit_end']) and end >= int(iv['hit_start']):
                    a=attrs_to_dict(attrs)
                    rows.append({
                        'blast_source_file':iv.get('source_file',''), 'assay':iv.get('assay',''),
                        'blast_interval':f"{iv['subject_accession']}:{iv['hit_start']}-{iv['hit_end']}",
                        'feature_type':ftype, 'feature_start':start, 'feature_end':end, 'strand':strand,
                        'feature_id':a.get('ID',''), 'gene':a.get('gene',''), 'name':a.get('Name',''),
                        'product':a.get('product',''), 'attributes':attrs
                    })
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    fields=['blast_source_file','assay','blast_interval','feature_type','feature_start','feature_end','strand','feature_id','gene','name','product','attributes']
    with open(args.out,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'Wrote {len(rows)} overlap rows to {args.out}')

if __name__ == '__main__': main()
