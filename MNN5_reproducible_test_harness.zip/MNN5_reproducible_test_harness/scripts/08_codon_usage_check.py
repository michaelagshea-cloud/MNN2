#!/usr/bin/env python3
"""Compute codon counts and compare to a supplied host codon usage table.
No optimization is performed; this is analysis only.
"""
import argparse, csv
from pathlib import Path

def read_seq(p): return ''.join(l.strip().upper() for l in open(p) if not l.startswith('>'))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--cds-fasta', required=True); ap.add_argument('--codon-usage-csv', required=True); ap.add_argument('--out', default='reports/codon_usage_check.csv'); args=ap.parse_args()
    if not Path(args.cds_fasta).exists() or not Path(args.codon_usage_csv).exists():
        Path(args.out).write_text('status,reason\nNOT_RUN_MISSING_INPUT,Provide CDS FASTA and codon usage CSV with codon,frequency\n'); return
    seq=read_seq(args.cds_fasta); counts={seq[i:i+3]:0 for i in range(0,len(seq)-2,3)}
    for i in range(0,len(seq)-2,3): counts[seq[i:i+3]]=counts.get(seq[i:i+3],0)+1
    usage={}
    with open(args.codon_usage_csv,newline='') as f:
        for r in csv.DictReader(f): usage[r['codon'].upper()]=r.get('frequency','')
    with open(args.out,'w',newline='') as f:
        w=csv.writer(f); w.writerow(['codon','count','host_frequency'])
        for codon,count in sorted(counts.items()): w.writerow([codon,count,usage.get(codon,'MISSING_FROM_TABLE')])
if __name__ == '__main__': main()
