#!/usr/bin/env python3
"""Run FBA on a supplied yeast-GEM model using COBRApy.
This script fails closed: without model, gene ID, and optional medium constraints, it outputs NOT_RUN.
"""
import argparse, csv, json
from pathlib import Path

def write_status(out, status, reason):
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps({'status':status,'reason':reason}, indent=2))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model', required=True, help='SBML/XML/JSON model file')
    ap.add_argument('--gene-id', required=True, help='Gene ID to knock out; verify exact ID in model')
    ap.add_argument('--medium-csv', default=None, help='Optional CSV: reaction_id,lower_bound,upper_bound')
    ap.add_argument('--out-json', default='reports/fba_result.json')
    ap.add_argument('--out-flux-csv', default='reports/fba_fluxes.csv')
    args=ap.parse_args()
    if not Path(args.model).exists():
        write_status(args.out_json,'NOT_RUN_MISSING_MODEL',f'Model file not found: {args.model}'); return
    try:
        import cobra
    except Exception as e:
        write_status(args.out_json,'NOT_RUN_MISSING_DEPENDENCY',f'COBRApy import failed: {e}'); return
    try:
        model = cobra.io.read_sbml_model(args.model) if args.model.lower().endswith(('.xml','.sbml')) else cobra.io.load_json_model(args.model)
        if args.medium_csv:
            with open(args.medium_csv, newline='') as f:
                for r in csv.DictReader(f):
                    rxn=model.reactions.get_by_id(r['reaction_id'])
                    if r.get('lower_bound')!='': rxn.lower_bound=float(r['lower_bound'])
                    if r.get('upper_bound')!='': rxn.upper_bound=float(r['upper_bound'])
        wt = model.optimize()
        ko_model = model.copy()
        ko_model.genes.get_by_id(args.gene_id).knock_out()
        ko = ko_model.optimize()
        result={'status':'COMPLETE','model':args.model,'gene_id':args.gene_id,'wt_status':wt.status,'wt_objective':wt.objective_value,'ko_status':ko.status,'ko_objective':ko.objective_value}
        Path(args.out_json).write_text(json.dumps(result, indent=2))
        with open(args.out_flux_csv,'w',newline='') as f:
            w=csv.writer(f); w.writerow(['reaction_id','wt_flux','ko_flux'])
            for rxn in model.reactions:
                w.writerow([rxn.id, wt.fluxes.get(rxn.id, ''), ko.fluxes.get(rxn.id, '')])
    except Exception as e:
        write_status(args.out_json,'FAILED_WITH_ERROR',str(e))

if __name__ == '__main__': main()
