#!/usr/bin/env python3
"""Parse the uploaded MNN5 Archive.zip into reproducible evidence reports.
This script does not infer biological validation; it only summarizes files present.
"""
import argparse, csv, hashlib, re, shutil, zipfile
from pathlib import Path

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def parse_blast(path):
    txt=path.read_text(errors='replace')
    def grab(pat):
        m=re.search(pat, txt)
        return m.groups() if m else None
    row={'source_file':path.name,'sha256':sha256(path)}
    row['job_title']=(grab(r'Job Title:([^\n\r]+)') or [''])[0].strip()
    row['database']=(grab(r'Database:\s*(.+)') or [''])[0].strip()
    row['query_length_bp']=(grab(r'Query #1:.*?Length:\s*(\d+)') or [''])[0]
    subj=grab(r'Sequence ID:\s*([A-Z0-9_.]+)\s+Length:\s*(\d+)')
    if subj: row['subject_accession'], row['subject_length_bp']=subj
    ran=grab(r'Range 1:\s*(\d+)\s+to\s+(\d+)')
    if ran: row['hit_start'], row['hit_end']=ran
    ids=grab(r'Identities:(\d+)/(\d+)\((\d+)%\)')
    if ids:
        ident, aln, pct = map(int, ids)
        row['identities']=ident; row['alignment_length']=aln
        row['identity_percent_reported']=pct; row['identity_percent_exact']=round(100*ident/aln,4)
    gaps=grab(r'Gaps:(\d+)/(\d+)\((\d+)%\)')
    row['gaps']=gaps[0] if gaps else ''
    row['strand']=(grab(r'Strand:\s*([^\n\r]+)') or [''])[0].strip()
    low=path.name.lower()
    if 'left' in low: row['assay']='Left native/outside region BLAST placement'
    elif 'right' in low: row['assay']='Right native/outside region BLAST placement'
    elif 'orf' in low: row['assay']='Native ORF-loss/internal assay segment BLAST placement'
    else: row['assay']=path.stem
    return row

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=fields or ['empty']); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--archive', required=True)
    ap.add_argument('--out', default='reports')
    args=ap.parse_args()
    archive=Path(args.archive); out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    tmp=out/'_extracted'
    if tmp.exists(): shutil.rmtree(tmp)
    with zipfile.ZipFile(archive) as z: z.extractall(tmp)
    blast=[parse_blast(p) for p in sorted(tmp.rglob('*BLAST*.txt')) if '__MACOSX' not in str(p)]
    write_csv(out/'blast_summary.csv', blast)
    neb_rows=[]
    for p in sorted(tmp.rglob('*NEB*csv')):
        if '__MACOSX' in str(p): continue
        with open(p, newline='', encoding='utf-8-sig') as f:
            for r in csv.DictReader(f):
                r={**r, 'source_file':p.name, 'audit_status':'PROVEN_FROM_UPLOADED_RECORDS_ONLY'}
                neb_rows.append(r)
    write_csv(out/'primer_panel_summary.csv', neb_rows)
    print(f'Parsed {len(blast)} BLAST report(s) and {len(neb_rows)} primer panel row(s).')

if __name__ == '__main__': main()
