# Source register

These are the external sources/tools this harness is designed to use. Include exact versions and local checksums when you run them.

1. NCBI Datasets genome package documentation: https://www.ncbi.nlm.nih.gov/datasets/docs/v2/reference-docs/command-line/datasets/download/genome/
2. NCBI genome data packages can include genomic FASTA, GFF3/GTF/GBFF annotation, and metadata: https://www.ncbi.nlm.nih.gov/datasets/docs/v2/reference-docs/data-packages/genome/
3. yeast-GEM official repository: https://github.com/SysBioChalmers/yeast-GEM
4. yeast-GEM documentation: https://sysbiochalmers.github.io/yeast-GEM/
5. COBRApy documentation: https://cobrapy.readthedocs.io/
6. COBRApy GitHub: https://github.com/opencobra/cobrapy
7. AlphaGenome API repository: https://github.com/google-deepmind/alphagenome

Do not cite outputs from these tools unless the raw input files, exact command, software version, and raw output files are committed in the repository.
