# QUARANTINE: unsupported claims not allowed in reports

Do not cite or reuse these claims unless raw supporting files are added and the corresponding script produces a verifiable output:

- ALL TESTS PASS
- computationally verified
- AlphaGenome confirmed
- no off-targets
- no toxic fragments
- FBA predicts a 0.8% growth reduction
- 64% mannan flux reduction
- P39107 is MNN5
- the 725 bp product is the full MNN5 ORF
- synthetic FASTQ proves the real edit

The 725 bp BLAST placement should be labeled as a native/internal ORF-loss assay segment until GFF3 annotation proves exact gene boundaries.
