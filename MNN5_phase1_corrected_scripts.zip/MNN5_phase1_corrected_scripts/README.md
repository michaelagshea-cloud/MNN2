# Corrected Phase 1 scripts for MNN5 CEN.PK113-7D

This package fixes the latest agent output.

## Important corrections

1. T01 now creates `reports/`, checks that NCBI Datasets exists, confirms FASTA/GFF files were downloaded, and writes checksums.
2. T02 now reports all overlapping features, does not rely on a single fragile GFF match, and writes a decision markdown file.
3. T03 no longer stops after raw primersearch output. It performs a direct in silico PCR scan and writes both raw hits and a pass/fail summary CSV.

## Install / setup

Copy these files into your repository:

```text
scripts/T01_download_reference.sh
scripts/T02_verify_gff_overlap.py
scripts/T03_in_silico_pcr_specificity.py
scripts/run_phase1_foundation_tests.sh
config/primer_pairs.tsv
```

Edit `config/primer_pairs.tsv` and replace `PASTE_FORWARD_SEQUENCE_HERE` / `PASTE_REVERSE_SEQUENCE_HERE` for the Native ORF loss assay if those sequences are available.

## Run

```bash
chmod +x scripts/T01_download_reference.sh scripts/run_phase1_foundation_tests.sh
bash scripts/run_phase1_foundation_tests.sh
```

## Outputs to cite in a research paper

```text
reports/T01_reference_checksums.sha256
reports/T02_gff_overlap_check.csv
reports/T02_orf_boundary_decision.md
reports/T03_primer_specificity_summary.csv
reports/T03_in_silico_pcr_hits.csv
MANIFEST.sha256
```
