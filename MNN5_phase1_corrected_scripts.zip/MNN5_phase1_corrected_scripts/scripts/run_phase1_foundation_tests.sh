#!/usr/bin/env bash
set -euo pipefail

mkdir -p reports logs data_intermediate

echo "Running T00 status check is not included in this Phase 1 correction package."
echo "Run your existing T00 script first if blast_summary.csv does not already exist."

if [ ! -f reports/blast_summary.csv ]; then
  echo "ERROR: reports/blast_summary.csv is missing. Run T00 archive audit first." >&2
  exit 1
fi

if [ ! -f config/primer_pairs.tsv ]; then
  echo "ERROR: config/primer_pairs.tsv is missing." >&2
  exit 1
fi

echo "Step T01: Reference download"
bash scripts/T01_download_reference.sh

GFF=$(find data_raw/reference -type f \( -name "*.gff" -o -name "*.gff3" \) | sort | head -n 1)
FASTA=$(find data_raw/reference -type f \( -name "*.fna" -o -name "*.fa" -o -name "*.fasta" \) | sort | head -n 1)

if [ -z "$GFF" ] || [ -z "$FASTA" ]; then
  echo "ERROR: could not locate FASTA/GFF after T01." >&2
  exit 1
fi

echo "Using GFF: $GFF"
echo "Using FASTA: $FASTA"

echo "Step T02: GFF overlap"
python scripts/T02_verify_gff_overlap.py \
  --gff3 "$GFF" \
  --blast-summary reports/blast_summary.csv \
  --target-name MNN5 \
  --target-systematic YJL186W \
  --out reports/T02_gff_overlap_check.csv \
  --decision-md reports/T02_orf_boundary_decision.md

echo "Step T03: Primer specificity"
python scripts/T03_in_silico_pcr_specificity.py \
  --fasta "$FASTA" \
  --primers config/primer_pairs.tsv \
  --max-mismatches 3 \
  --max-product 3000 \
  --out reports/T03_in_silico_pcr_hits.csv \
  --summary reports/T03_primer_specificity_summary.csv

echo "Updating checksum manifest"
find . -type f ! -path "./.git/*" ! -name "MANIFEST.sha256" -exec sha256sum {} \; | sort > MANIFEST.sha256

echo "Phase 1 complete. Review:"
echo "  reports/T02_gff_overlap_check.csv"
echo "  reports/T02_orf_boundary_decision.md"
echo "  reports/T03_primer_specificity_summary.csv"
echo "  reports/T03_in_silico_pcr_hits.csv"
