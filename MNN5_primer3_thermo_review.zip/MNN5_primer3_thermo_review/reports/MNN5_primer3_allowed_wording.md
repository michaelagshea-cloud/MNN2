# MNN5 Primer3 allowed wording

Primer3-py successfully ran on the four MNN5 primer pairs. Three of four primer pairs passed the configured in-silico thermodynamic gate. The current full primer panel is not order-ready because the MNN5 5prime true integration junction FIRSTPASS pair failed due to the forward primer homodimer ΔG check.

This is an in-silico primer thermodynamic review only. It is not wet-lab validation and does not prove experimental performance.
