# Not-supported claims

Do not claim:
- the full MNN5 primer panel is order-ready
- all primer tests passed
- wet-lab validation has been completed
- the edit is experimentally confirmed
- the failed 5prime junction pair should be ordered as-is
