#!/usr/bin/env python3
"""
run_MNN5_redesign_failed_5prime_forward_only.py

Tightly scoped MNN5 primer redesign:
- Only redesigns the failed 5' junction forward primer.
- Keeps the existing 5' junction reverse primer if a passing forward candidate is found.
- Does not change the three passing primer pairs.
- Screens candidate forward primers with primer3-py thermodynamics.
- Does not claim wet-lab validation or order-readiness.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional

OUTDIR = Path("/mnt/data/MNN5_5prime_forward_only_redesign_outputs")
OUTZIP = Path("/mnt/data/MNN5_5prime_forward_only_redesign_outputs.zip")

REFERENCE_FASTA = Path("/mnt/data/unedited_CP022975.1(1).fasta")
REVIEW_DIR = Path("/mnt/data/MNN5_primer3_thermo_review")
FULL_RESULTS_CSV = REVIEW_DIR / "reports" / "MNN5_primer3_full_results.csv"
THRESHOLDS_JSON = REVIEW_DIR / "source" / "MNN5_primer3_thermo_thresholds.json"
PROMPT_PATH = REVIEW_DIR / "next_step" / "prompt_for_code_agent_redesign_failed_5prime_forward_only.txt"

FAILED_ASSAY = "MNN5_5prime_true_integration_junction_FIRSTPASS"
FAILED_FORWARD = "TCGCGTCGCAAATTGTGATG"
KEEP_REVERSE = "TTTTCTAGAACCGCCACCAC"

# Coordinates carried forward from the prior strict preorder/specificity package.
# MNN5 original interval: 92610-94370 on CP022975.1 plus strand.
# Left homology arm length: 500 bp; therefore left arm is 92110-92609.
# Candidate forward primers must remain upstream/outside of this arm.
MNN5_ORIGINAL_INTERVAL_START_1BASED = 92610
LEFT_HOMOLOGY_ARM_LEN_BP = 500
OUTSIDE_LEFT_REGION_START_1BASED = MNN5_ORIGINAL_INTERVAL_START_1BASED - (2 * LEFT_HOMOLOGY_ARM_LEN_BP)
OUTSIDE_LEFT_REGION_END_1BASED = MNN5_ORIGINAL_INTERVAL_START_1BASED - LEFT_HOMOLOGY_ARM_LEN_BP - 1
LEFT_HOMOLOGY_ARM_START_1BASED = MNN5_ORIGINAL_INTERVAL_START_1BASED - LEFT_HOMOLOGY_ARM_LEN_BP

# Existing 5' reverse-primer reverse-complement start from prior edited-context exact match report.
EXISTING_REVERSE_RC_START_EDITED_1BASED = 92761
ORIGINAL_EXPECTED_PRODUCT_BP = 806

PRIMER_LENGTHS = range(18, 26)
GC_MIN = 40.0
GC_MAX = 60.0
EXPECTED_PRODUCT_MIN_BP = 650
EXPECTED_PRODUCT_MAX_BP = 1000
TOP_N = 10
MIN_START_SEPARATION_FOR_TOP_TABLE_BP = 5


def reset_outputs() -> None:
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    if OUTZIP.exists():
        OUTZIP.unlink()
    OUTDIR.mkdir(parents=True, exist_ok=True)


def read_fasta(path: Path) -> Dict[str, str]:
    header: Optional[str] = None
    chunks: List[str] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is None:
                    header = line[1:]
                continue
            chunks.append(line.upper())
    if header is None:
        raise ValueError(f"No FASTA header found: {path}")
    seq = "".join(chunks)
    if not seq:
        raise ValueError(f"No FASTA sequence found: {path}")
    return {"header": header, "sequence": seq}


def gc_percent(seq: str) -> float:
    return 100.0 * (seq.count("G") + seq.count("C")) / len(seq)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: Optional[List[str]] = None) -> None:
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def load_thresholds(path: Path) -> Dict[str, float]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        "tm_min_c": float(data["tm_min_c"]),
        "tm_max_c": float(data["tm_max_c"]),
        "max_pair_tm_difference_c": float(data["max_pair_tm_difference_c"]),
        "min_hairpin_dg_cal_mol": float(data["min_hairpin_dg_cal_mol"]),
        "min_homodimer_dg_cal_mol": float(data["min_homodimer_dg_cal_mol"]),
        "min_heterodimer_dg_cal_mol": float(data["min_heterodimer_dg_cal_mol"]),
    }


def try_import_primer3():
    try:
        import primer3  # type: ignore
        return primer3
    except ModuleNotFoundError:
        return None


def thermo_values(primer3, fwd_seq: str, rev_seq: str) -> Dict[str, float]:
    return {
        "tm_c": float(primer3.calc_tm(fwd_seq)),
        "hairpin_dg_cal_mol": float(primer3.calc_hairpin(fwd_seq).dg),
        "homodimer_dg_cal_mol": float(primer3.calc_homodimer(fwd_seq).dg),
        "heterodimer_dg_cal_mol": float(primer3.calc_heterodimer(fwd_seq, rev_seq).dg),
    }


def primer_pair_thermo(primer3, fwd_seq: str, rev_seq: str, thresholds: Dict[str, float]) -> Dict[str, object]:
    f_tm = float(primer3.calc_tm(fwd_seq))
    r_tm = float(primer3.calc_tm(rev_seq))
    f_hairpin = float(primer3.calc_hairpin(fwd_seq).dg)
    r_hairpin = float(primer3.calc_hairpin(rev_seq).dg)
    f_homodimer = float(primer3.calc_homodimer(fwd_seq).dg)
    r_homodimer = float(primer3.calc_homodimer(rev_seq).dg)
    heterodimer = float(primer3.calc_heterodimer(fwd_seq, rev_seq).dg)
    pair_tm_diff = abs(f_tm - r_tm)

    checks = {
        "forward_tm_check": thresholds["tm_min_c"] <= f_tm <= thresholds["tm_max_c"],
        "reverse_tm_check": thresholds["tm_min_c"] <= r_tm <= thresholds["tm_max_c"],
        "pair_tm_difference_check": pair_tm_diff <= thresholds["max_pair_tm_difference_c"],
        "forward_hairpin_dg_check": f_hairpin >= thresholds["min_hairpin_dg_cal_mol"],
        "reverse_hairpin_dg_check": r_hairpin >= thresholds["min_hairpin_dg_cal_mol"],
        "forward_homodimer_dg_check": f_homodimer >= thresholds["min_homodimer_dg_cal_mol"],
        "reverse_homodimer_dg_check": r_homodimer >= thresholds["min_homodimer_dg_cal_mol"],
        "heterodimer_dg_check": heterodimer >= thresholds["min_heterodimer_dg_cal_mol"],
    }

    return {
        "forward_tm_c": round(f_tm, 3),
        "reverse_tm_c": round(r_tm, 3),
        "pair_tm_difference_c": round(pair_tm_diff, 3),
        "forward_hairpin_dg_cal_mol": round(f_hairpin, 3),
        "reverse_hairpin_dg_cal_mol": round(r_hairpin, 3),
        "forward_homodimer_dg_cal_mol": round(f_homodimer, 3),
        "reverse_homodimer_dg_cal_mol": round(r_homodimer, 3),
        "heterodimer_dg_cal_mol": round(heterodimer, 3),
        **{k: "PASS" if v else "FAIL" for k, v in checks.items()},
        "all_thermo_checks_pass": "PASS" if all(checks.values()) else "FAIL",
    }


def generate_candidate_rows(primer3, ref_seq: str, thresholds: Dict[str, float]) -> List[Dict[str, object]]:
    reverse_tm = float(primer3.calc_tm(KEEP_REVERSE))
    rows: List[Dict[str, object]] = []

    for start_1based in range(OUTSIDE_LEFT_REGION_START_1BASED, OUTSIDE_LEFT_REGION_END_1BASED + 1):
        for length in PRIMER_LENGTHS:
            end_1based = start_1based + length - 1
            if end_1based > OUTSIDE_LEFT_REGION_END_1BASED:
                continue

            seq = ref_seq[start_1based - 1 : end_1based]
            if len(seq) != length or set(seq) - set("ACGT"):
                continue
            if seq == FAILED_FORWARD:
                continue

            gc = gc_percent(seq)
            if not (GC_MIN <= gc <= GC_MAX):
                continue

            tv = thermo_values(primer3, seq, KEEP_REVERSE)
            pair_tm_diff = abs(tv["tm_c"] - reverse_tm)
            expected_product_bp = EXISTING_REVERSE_RC_START_EDITED_1BASED + len(KEEP_REVERSE) - start_1based

            checks = {
                "outside_left_homology_arm_check": end_1based < LEFT_HOMOLOGY_ARM_START_1BASED,
                "gc_check": GC_MIN <= gc <= GC_MAX,
                "tm_check": thresholds["tm_min_c"] <= tv["tm_c"] <= thresholds["tm_max_c"],
                "pair_tm_difference_check": pair_tm_diff <= thresholds["max_pair_tm_difference_c"],
                "hairpin_dg_check": tv["hairpin_dg_cal_mol"] >= thresholds["min_hairpin_dg_cal_mol"],
                "homodimer_dg_check": tv["homodimer_dg_cal_mol"] >= thresholds["min_homodimer_dg_cal_mol"],
                "heterodimer_dg_check": tv["heterodimer_dg_cal_mol"] >= thresholds["min_heterodimer_dg_cal_mol"],
                "expected_product_size_check": EXPECTED_PRODUCT_MIN_BP <= expected_product_bp <= EXPECTED_PRODUCT_MAX_BP,
            }

            rows.append(
                {
                    "sequence": seq,
                    "start_1based_unedited_CP022975_1": start_1based,
                    "end_1based_unedited_CP022975_1": end_1based,
                    "length_nt": length,
                    "gc_percent": round(gc, 2),
                    "tm_c": round(tv["tm_c"], 3),
                    "existing_reverse_primer": KEEP_REVERSE,
                    "existing_reverse_tm_c": round(reverse_tm, 3),
                    "pair_tm_difference_c": round(pair_tm_diff, 3),
                    "hairpin_dg_cal_mol": round(tv["hairpin_dg_cal_mol"], 3),
                    "homodimer_dg_cal_mol": round(tv["homodimer_dg_cal_mol"], 3),
                    "heterodimer_dg_cal_mol_with_existing_reverse": round(tv["heterodimer_dg_cal_mol"], 3),
                    "expected_product_size_bp_if_existing_reverse_position_is_preserved": expected_product_bp,
                    "product_delta_from_original_806_bp": expected_product_bp - ORIGINAL_EXPECTED_PRODUCT_BP,
                    "homodimer_margin_vs_cutoff_cal_mol": round(
                        tv["homodimer_dg_cal_mol"] - thresholds["min_homodimer_dg_cal_mol"], 3
                    ),
                    "hairpin_margin_vs_cutoff_cal_mol": round(
                        tv["hairpin_dg_cal_mol"] - thresholds["min_hairpin_dg_cal_mol"], 3
                    ),
                    "heterodimer_margin_vs_cutoff_cal_mol": round(
                        tv["heterodimer_dg_cal_mol"] - thresholds["min_heterodimer_dg_cal_mol"], 3
                    ),
                    **{k: "PASS" if v else "FAIL" for k, v in checks.items()},
                    "overall_candidate_thermo_status": "PASS" if all(checks.values()) else "FAIL",
                    "claim_status": "THERMO_SCREEN_ONLY_NOT_WET_LAB_VALIDATED_NOT_ORDER_READY",
                }
            )
    return rows


def top_candidate_sort_key(row: Dict[str, object]) -> tuple:
    # Failure was forward homodimer ΔG; prioritize margin away from that cutoff,
    # then keep the amplicon close to the original 806 bp assay.
    homodimer_margin = float(row["homodimer_margin_vs_cutoff_cal_mol"])
    product_delta = abs(int(row["product_delta_from_original_806_bp"]))
    pair_tm_diff = float(row["pair_tm_difference_c"])
    length_delta = abs(int(row["length_nt"]) - 22)
    return (-homodimer_margin, product_delta, pair_tm_diff, length_delta)


def choose_top_candidates(candidate_rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    passing = [r for r in candidate_rows if r["overall_candidate_thermo_status"] == "PASS"]
    passing.sort(key=top_candidate_sort_key)

    selected: List[Dict[str, object]] = []
    selected_starts: List[int] = []
    for row in passing:
        start = int(row["start_1based_unedited_CP022975_1"])
        if all(abs(start - s) >= MIN_START_SEPARATION_FOR_TOP_TABLE_BP for s in selected_starts):
            selected.append(dict(row))
            selected_starts.append(start)
        if len(selected) == TOP_N:
            break

    for rank, row in enumerate(selected, start=1):
        row["candidate_rank"] = rank
    return selected


def build_updated_panel_thermo(primer3, top_candidate: Dict[str, object], thresholds: Dict[str, float]) -> List[Dict[str, object]]:
    prior_rows = read_csv(FULL_RESULTS_CSV)
    updated: List[Dict[str, object]] = []
    top_forward = str(top_candidate["sequence"])

    for row in prior_rows:
        assay = row["pair_id"]
        if assay == FAILED_ASSAY:
            fwd = top_forward
            rev = KEEP_REVERSE
            redesign_status = "REDESIGNED_FORWARD_ONLY_REVERSE_PRESERVED"
        else:
            fwd = row["forward_primer"]
            rev = row["reverse_primer"]
            redesign_status = "UNCHANGED_PRIOR_THERMO_PASSING_PAIR"

        thermo = primer_pair_thermo(primer3, fwd, rev, thresholds)
        updated.append(
            {
                "pair_id": assay,
                "forward_primer": fwd,
                "reverse_primer": rev,
                "redesign_status": redesign_status,
                **thermo,
                "order_readiness": "NOT_ORDER_READY_PENDING_THREE_CONTEXT_SPECIFICITY_RERUN",
            }
        )
    return updated


def zip_outputs() -> None:
    with zipfile.ZipFile(OUTZIP, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(OUTDIR.rglob("*")):
            if path.is_file():
                zf.write(path, arcname=str(path.relative_to(OUTDIR)))


def main() -> int:
    reset_outputs()

    primer3 = try_import_primer3()
    if primer3 is None:
        (OUTDIR / "NOT_RUN_MISSING_PRIMER3_MODULE.txt").write_text(
            "NOT_RUN_MISSING_PRIMER3_MODULE\n", encoding="utf-8"
        )
        (OUTDIR / "MNN5_5prime_forward_redesign_decision.txt").write_text(
            "NOT_ORDER_READY\nPrimer3-py is missing. Thermodynamic values were not calculated and were not invented.\n",
            encoding="utf-8",
        )
        zip_outputs()
        return 0

    thresholds = load_thresholds(THRESHOLDS_JSON)
    fasta = read_fasta(REFERENCE_FASTA)
    ref_seq = fasta["sequence"]

    candidate_rows = generate_candidate_rows(primer3, ref_seq, thresholds)
    top_candidates = choose_top_candidates(candidate_rows)

    all_fieldnames = list(candidate_rows[0].keys()) if candidate_rows else []
    top_fieldnames = ["candidate_rank"] + [k for k in all_fieldnames if k != "candidate_rank"]

    write_csv(OUTDIR / "MNN5_5prime_forward_all_candidates_primer3_thermo.csv", candidate_rows, all_fieldnames)
    write_csv(OUTDIR / "MNN5_5prime_forward_top10_candidates_primer3_thermo.csv", top_candidates, top_fieldnames)

    if not top_candidates:
        decision = "NOT_ORDER_READY\nNo passing forward-primer candidate was found while preserving the existing reverse primer.\n"
        summary = {
            "status": "NO_PASSING_FORWARD_CANDIDATE_WITH_EXISTING_REVERSE",
            "candidate_count_total": len(candidate_rows),
            "candidate_count_passing_thermo": 0,
            "existing_reverse_preserved": True,
            "wet_lab_validation_claimed": False,
            "order_readiness": "NOT_ORDER_READY",
        }
    else:
        best = top_candidates[0]
        updated_panel = build_updated_panel_thermo(primer3, best, thresholds)
        write_csv(OUTDIR / "MNN5_updated_primer_panel_forward_only_replacement_thermo.csv", updated_panel)

        updated_minimal_panel = []
        for row in updated_panel:
            updated_minimal_panel.append(
                {
                    "pair_id": row["pair_id"],
                    "forward_primer": row["forward_primer"],
                    "reverse_primer": row["reverse_primer"],
                    "redesign_status": row["redesign_status"],
                }
            )
        write_csv(OUTDIR / "MNN5_updated_primer_panel_forward_only_replacement.csv", updated_minimal_panel)

        all_panel_thermo_pass = all(r["all_thermo_checks_pass"] == "PASS" for r in updated_panel)
        decision = (
            "NOT_ORDER_READY_PENDING_THREE_CONTEXT_SPECIFICITY_RERUN\n"
            "A replacement 5prime forward primer passed the configured Primer3 thermodynamic screen with the existing reverse primer.\n"
            "The three previously passing pairs were not redesigned.\n"
            "No wet-lab validation is claimed.\n"
            "Do not order until the prior three-context specificity test is rerun for the updated 5prime junction pair.\n"
        )
        summary = {
            "status": "PASSING_FORWARD_CANDIDATE_FOUND_THERMO_ONLY",
            "candidate_count_total": len(candidate_rows),
            "candidate_count_passing_thermo": sum(
                1 for r in candidate_rows if r["overall_candidate_thermo_status"] == "PASS"
            ),
            "top_candidate_forward_primer": best["sequence"],
            "top_candidate_existing_reverse_primer": KEEP_REVERSE,
            "top_candidate_expected_product_size_bp_if_existing_reverse_position_is_preserved": best[
                "expected_product_size_bp_if_existing_reverse_position_is_preserved"
            ],
            "top_candidate_forward_homodimer_dg_cal_mol": best["homodimer_dg_cal_mol"],
            "top_candidate_thermo_status": best["overall_candidate_thermo_status"],
            "updated_four_pair_panel_thermo_status": "PASS" if all_panel_thermo_pass else "FAIL",
            "existing_reverse_preserved": True,
            "changed_pairs": [FAILED_ASSAY],
            "unchanged_pairs": [
                "MNN5_3prime_true_integration_junction_FIRSTPASS",
                "MNN5_native_ORF_loss_SUPPORT",
                "MNN5_insert_internal_SUPPORT",
            ],
            "three_context_specificity_rerun": False,
            "wet_lab_validation_claimed": False,
            "order_readiness": "NOT_ORDER_READY_PENDING_THREE_CONTEXT_SPECIFICITY_RERUN",
        }

    (OUTDIR / "MNN5_5prime_forward_redesign_decision.txt").write_text(decision, encoding="utf-8")
    (OUTDIR / "MNN5_5prime_forward_redesign_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    (OUTDIR / "MNN5_5prime_forward_redesign_thresholds.json").write_text(
        json.dumps(thresholds, indent=2) + "\n", encoding="utf-8"
    )

    context = {
        "reference_fasta": str(REFERENCE_FASTA),
        "reference_header": fasta["header"],
        "reference_length_bp": len(ref_seq),
        "reference_sha256_clean_sequence": sha256_text(ref_seq),
        "outside_left_region_start_1based": OUTSIDE_LEFT_REGION_START_1BASED,
        "outside_left_region_end_1based": OUTSIDE_LEFT_REGION_END_1BASED,
        "left_homology_arm_start_1based": LEFT_HOMOLOGY_ARM_START_1BASED,
        "candidate_requirement": "forward primer end must be less than left_homology_arm_start_1based",
        "existing_reverse_rc_start_edited_1based": EXISTING_REVERSE_RC_START_EDITED_1BASED,
        "existing_reverse_primer_preserved": KEEP_REVERSE,
        "original_failed_forward_primer": FAILED_FORWARD,
        "original_expected_product_bp": ORIGINAL_EXPECTED_PRODUCT_BP,
        "primer3_py_available": True,
        "primer3_py_version": getattr(primer3, "__version__", "unknown"),
    }
    (OUTDIR / "MNN5_5prime_forward_redesign_context.json").write_text(
        json.dumps(context, indent=2) + "\n", encoding="utf-8"
    )

    if PROMPT_PATH.exists():
        shutil.copy2(PROMPT_PATH, OUTDIR / "prompt_used_redesign_failed_5prime_forward_only.txt")

    shutil.copy2(Path(__file__), OUTDIR / "run_MNN5_redesign_failed_5prime_forward_only.py")

    # Checksums last, after all files except the zip itself.
    manifest_rows = []
    for path in sorted(OUTDIR.rglob("*")):
        if path.is_file():
            manifest_rows.append(
                {
                    "file": str(path.relative_to(OUTDIR)),
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            )
    write_csv(OUTDIR / "MANIFEST.sha256.csv", manifest_rows, ["file", "sha256"])

    zip_outputs()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
