# Not-supported claims

Do not claim:
- wet-lab validation completed
- edited strain experimentally confirmed
- full genome-wide mismatch-tolerant specificity screen completed
- no possible off-target products under all mismatch settings
- functional phenotype confirmed
- publication-level validation complete
