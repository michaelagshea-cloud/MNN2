# Negative off-target candidate-site definition plan

For AUROC and PR-AUC, positives alone are not enough. Each empirical off-target dataset must define an explicit candidate universe.

Recommended rule:

1. For each guide, enumerate all genomic candidate sites with the relevant PAM and a prespecified mismatch/bulge limit.
2. Label experimentally detected sites as positives.
3. Label non-detected sites within the same searchable candidate universe as negatives.
4. Record the enumeration method, reference genome, PAM rule, maximum mismatches, bulge allowance, and tool version.
5. Do not treat a reported count of discovered off-targets as the full positive-plus-negative candidate universe.

Important caution:
The CHANGE-seq row’s large reported off-target-site count may be source-consistent for identified off-target sites, but it is not automatically a full benchmark candidate universe. AUROC/PR-AUC require explicit negatives.
