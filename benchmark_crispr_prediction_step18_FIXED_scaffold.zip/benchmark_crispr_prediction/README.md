# benchmark_crispr_prediction — fixed Step 18 scaffold

This patched scaffold fixes the Step 18 issues identified during review.

## What this scaffold supports

- Input schemas for independent empirical benchmarking.
- Metric functions for AUROC, PR-AUC, sensitivity, specificity, F1, MCC, recall at fixed FPR, Pearson r, Spearman rho, RMSE, MAE, top-k recall, enrichment, NDCG, and bootstrap confidence intervals.
- Fail-closed validation for missing files, missing columns, and empty placeholder files.
- Leakage-check script for train/test overlap.
- A correct requirements.txt.

## What this scaffold does not support yet

It does not support any benchmark-performance claim until real curated rows are added.

Not supported yet:
- AUROC/PR-AUC calculated
- rare off-target recall calculated
- Pearson/Spearman/RMSE/MAE calculated
- guide ranking completed
- baseline comparison completed
- train/test leakage ruled out on real data
- publication-level benchmark completed

## Required real inputs

Fill these files with curated rows before running metrics:

- data/processed/offtarget_standardized.csv
- data/processed/ontarget_standardized.csv
- data/predictions/your_pipeline_predictions.csv
- data/predictions/baseline_tool_predictions.csv

## Run commands

Install dependencies:

```bash
pip install -r requirements.txt
```

Run fail-closed benchmark validation/metrics:

```bash
cd benchmark_crispr_prediction
python -m benchmark_crispr_prediction.run_benchmark
```

Run leakage checks:

```bash
cd benchmark_crispr_prediction
python -m benchmark_crispr_prediction.leakage_checks
```

With placeholder header-only files, both commands should fail closed. That is expected.
