from __future__ import annotations

import csv
import json
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def overlap_by_key(rows: list[dict[str, str]], key_cols: list[str]) -> set[tuple[str, ...]]:
    train = set()
    test = set()
    for r in rows:
        key = tuple(r.get(c, "") for c in key_cols)
        split = r.get("split", "").lower()
        if split == "train":
            train.add(key)
        elif split == "test":
            test.add(key)
    return train & test


def run_leakage_checks(
    offtarget_path: str = "data/processed/offtarget_standardized.csv",
    ontarget_path: str = "data/processed/ontarget_standardized.csv",
    output_dir: str = "results/leakage",
) -> dict[str, object]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    checks = []

    for label, path_str in [("offtarget", offtarget_path), ("ontarget", ontarget_path)]:
        path = Path(path_str)
        try:
            rows = read_csv(path)
        except Exception as exc:
            checks.append({
                "dataset_type": label,
                "check_name": "file_read",
                "status": "FAIL_CLOSED_FILE_ERROR",
                "observed_value": str(exc),
                "allowed_value": "readable CSV with rows",
                "notes": "",
            })
            continue

        if not rows:
            checks.append({
                "dataset_type": label,
                "check_name": "non_empty_rows",
                "status": "FAIL_CLOSED_EMPTY_INPUTS",
                "observed_value": 0,
                "allowed_value": ">0",
                "notes": "",
            })
            continue

        guide_overlap = overlap_by_key(rows, ["guide_sequence"])
        checks.append({
            "dataset_type": label,
            "check_name": "guide_sequence_overlap_train_test",
            "status": "PASS" if len(guide_overlap) == 0 else "FAIL_LEAKAGE_DETECTED",
            "observed_value": len(guide_overlap),
            "allowed_value": 0,
            "notes": "No exact guide sequence should appear in both train and test for guide-held-out claims.",
        })

        if label == "offtarget":
            site_overlap = overlap_by_key(rows, ["guide_id", "chromosome", "position", "strand"])
            checks.append({
                "dataset_type": label,
                "check_name": "candidate_site_overlap_train_test",
                "status": "PASS" if len(site_overlap) == 0 else "FAIL_LEAKAGE_DETECTED",
                "observed_value": len(site_overlap),
                "allowed_value": 0,
                "notes": "No exact guide-site tuple should occur in both train and test.",
            })

    with (out / "train_test_leakage_checks.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["dataset_type", "check_name", "status", "observed_value", "allowed_value", "notes"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(checks)

    status = "FAIL_CLOSED_OR_LEAKAGE_DETECTED" if any(str(c["status"]).startswith("FAIL") for c in checks) else "PASS"
    report = {
        "status": status,
        "checks": checks,
        "leakage_ruled_out": status == "PASS",
        "benchmark_performance_claimed": False,
    }
    (out / "train_test_leakage_summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    result = run_leakage_checks()
    raise SystemExit(0 if result["status"] == "PASS" else 2)
