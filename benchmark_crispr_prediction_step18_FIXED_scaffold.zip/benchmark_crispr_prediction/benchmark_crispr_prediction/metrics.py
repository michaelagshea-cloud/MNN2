
from __future__ import annotations

import math
import random
from typing import Callable, Iterable, Sequence


Number = int | float


def _to_float_list(values: Sequence[Number]) -> list[float]:
    return [float(v) for v in values]


def _to_int_label_list(values: Sequence[Number]) -> list[int]:
    labels = [int(v) for v in values]
    bad = sorted(set(labels) - {0, 1})
    if bad:
        raise ValueError(f"Binary labels must be 0/1 only. Found: {bad}")
    return labels


def _check_equal_length(*arrays: Sequence[object]) -> None:
    lengths = {len(a) for a in arrays}
    if len(lengths) != 1:
        raise ValueError(f"Input arrays must have equal length. Found lengths: {sorted(lengths)}")
    if not lengths or next(iter(lengths)) == 0:
        raise ValueError("Input arrays must be non-empty.")


def _binary_confusion_counts(
    y_true: Sequence[Number],
    y_pred_label: Sequence[Number],
) -> tuple[int, int, int, int]:
    _check_equal_length(y_true, y_pred_label)
    yt = _to_int_label_list(y_true)
    yp = _to_int_label_list(y_pred_label)

    tp = sum(1 for a, b in zip(yt, yp) if a == 1 and b == 1)
    tn = sum(1 for a, b in zip(yt, yp) if a == 0 and b == 0)
    fp = sum(1 for a, b in zip(yt, yp) if a == 0 and b == 1)
    fn = sum(1 for a, b in zip(yt, yp) if a == 1 and b == 0)

    return tp, tn, fp, fn


def _rank_average(values: Sequence[Number]) -> list[float]:
    indexed = sorted(enumerate(_to_float_list(values)), key=lambda x: x[1])
    ranks = [0.0] * len(indexed)
    i = 0

    while i < len(indexed):
        j = i
        while j + 1 < len(indexed) and indexed[j + 1][1] == indexed[i][1]:
            j += 1

        avg_rank = (i + 1 + j + 1) / 2.0
        for k in range(i, j + 1):
            original_index = indexed[k][0]
            ranks[original_index] = avg_rank

        i = j + 1

    return ranks


def _trapz(x: Sequence[Number], y: Sequence[Number]) -> float:
    _check_equal_length(x, y)
    xf = _to_float_list(x)
    yf = _to_float_list(y)
    area = 0.0

    for i in range(1, len(xf)):
        width = xf[i] - xf[i - 1]
        height = (yf[i] + yf[i - 1]) / 2.0
        area += width * height

    return area


def auroc(y_true: Sequence[Number], y_score: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_score)
    yt = _to_int_label_list(y_true)
    ys = _to_float_list(y_score)

    n_pos = sum(yt)
    n_neg = len(yt) - n_pos

    if n_pos == 0 or n_neg == 0:
        raise ValueError("AUROC requires at least one positive and one negative label.")

    ranks = _rank_average(ys)
    sum_pos_ranks = sum(r for r, label in zip(ranks, yt) if label == 1)
    auc = (sum_pos_ranks - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)

    return float(auc)


def pr_auc(y_true: Sequence[Number], y_score: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_score)
    yt = _to_int_label_list(y_true)
    ys = _to_float_list(y_score)

    total_pos = sum(yt)
    if total_pos == 0:
        raise ValueError("PR-AUC requires at least one positive label.")

    pairs = sorted(zip(ys, yt), key=lambda x: x[0], reverse=True)

    precision = [1.0]
    recall = [0.0]
    tp = 0
    fp = 0

    for _, label in pairs:
        if label == 1:
            tp += 1
        else:
            fp += 1

        precision.append(tp / (tp + fp))
        recall.append(tp / total_pos)

    return float(_trapz(recall, precision))


def sensitivity(y_true: Sequence[Number], y_pred_label: Sequence[Number]) -> float:
    tp, _, _, fn = _binary_confusion_counts(y_true, y_pred_label)
    denom = tp + fn
    if denom == 0:
        raise ValueError("Sensitivity is undefined with zero positives.")
    return float(tp / denom)


def specificity(y_true: Sequence[Number], y_pred_label: Sequence[Number]) -> float:
    _, tn, fp, _ = _binary_confusion_counts(y_true, y_pred_label)
    denom = tn + fp
    if denom == 0:
        raise ValueError("Specificity is undefined with zero negatives.")
    return float(tn / denom)


def f1_score(y_true: Sequence[Number], y_pred_label: Sequence[Number]) -> float:
    tp, _, fp, fn = _binary_confusion_counts(y_true, y_pred_label)
    denom = (2 * tp) + fp + fn
    if denom == 0:
        raise ValueError("F1 is undefined when TP, FP, and FN are all zero.")
    return float((2 * tp) / denom)


def mcc(y_true: Sequence[Number], y_pred_label: Sequence[Number]) -> float:
    tp, tn, fp, fn = _binary_confusion_counts(y_true, y_pred_label)
    denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    if denom == 0:
        raise ValueError("MCC is undefined because the denominator is zero.")
    return float(((tp * tn) - (fp * fn)) / denom)


def recall_at_fixed_fpr(
    y_true: Sequence[Number],
    y_score: Sequence[Number],
    fixed_fpr: float = 0.01,
) -> float:
    _check_equal_length(y_true, y_score)
    yt = _to_int_label_list(y_true)
    ys = _to_float_list(y_score)

    if not 0.0 <= fixed_fpr <= 1.0:
        raise ValueError("fixed_fpr must be between 0 and 1.")

    n_pos = sum(yt)
    n_neg = len(yt) - n_pos

    if n_pos == 0 or n_neg == 0:
        raise ValueError("recall_at_fixed_fpr requires positives and negatives.")

    thresholds = sorted(set(ys), reverse=True)
    best_recall = 0.0

    for threshold in thresholds:
        y_pred = [1 if score >= threshold else 0 for score in ys]
        tp, _, fp, fn = _binary_confusion_counts(yt, y_pred)
        current_fpr = fp / n_neg
        current_recall = tp / (tp + fn) if (tp + fn) else 0.0

        if current_fpr <= fixed_fpr:
            best_recall = max(best_recall, current_recall)

    return float(best_recall)


def pearson_r(y_true: Sequence[Number], y_pred: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_pred)
    x = _to_float_list(y_true)
    y = _to_float_list(y_pred)

    mean_x = sum(x) / len(x)
    mean_y = sum(y) / len(y)

    num = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
    den_x = math.sqrt(sum((a - mean_x) ** 2 for a in x))
    den_y = math.sqrt(sum((b - mean_y) ** 2 for b in y))

    if den_x == 0 or den_y == 0:
        raise ValueError("Pearson r is undefined for constant input.")

    return float(num / (den_x * den_y))


def spearman_rho(y_true: Sequence[Number], y_pred: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_pred)
    rank_true = _rank_average(y_true)
    rank_pred = _rank_average(y_pred)
    return pearson_r(rank_true, rank_pred)


def rmse(y_true: Sequence[Number], y_pred: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_pred)
    x = _to_float_list(y_true)
    y = _to_float_list(y_pred)
    return float(math.sqrt(sum((a - b) ** 2 for a, b in zip(x, y)) / len(x)))


def mae(y_true: Sequence[Number], y_pred: Sequence[Number]) -> float:
    _check_equal_length(y_true, y_pred)
    x = _to_float_list(y_true)
    y = _to_float_list(y_pred)
    return float(sum(abs(a - b) for a, b in zip(x, y)) / len(x))


def top_k_recall(
    y_true: Sequence[Number],
    y_score: Sequence[Number],
    k: int,
) -> float:
    _check_equal_length(y_true, y_score)
    yt = _to_int_label_list(y_true)
    ys = _to_float_list(y_score)

    if k <= 0:
        raise ValueError("k must be positive.")

    total_pos = sum(yt)
    if total_pos == 0:
        raise ValueError("top_k_recall requires at least one positive label.")

    k = min(k, len(yt))
    top_indices = sorted(range(len(ys)), key=lambda i: ys[i], reverse=True)[:k]
    positives_found = sum(yt[i] for i in top_indices)

    return float(positives_found / total_pos)


def enrichment_at_k(
    y_true: Sequence[Number],
    y_score: Sequence[Number],
    k: int,
) -> float:
    _check_equal_length(y_true, y_score)
    yt = _to_int_label_list(y_true)
    ys = _to_float_list(y_score)

    if k <= 0:
        raise ValueError("k must be positive.")

    prevalence = sum(yt) / len(yt)
    if prevalence == 0:
        raise ValueError("enrichment_at_k requires at least one positive label.")

    k = min(k, len(yt))
    top_indices = sorted(range(len(ys)), key=lambda i: ys[i], reverse=True)[:k]
    top_rate = sum(yt[i] for i in top_indices) / k

    return float(top_rate / prevalence)


def ndcg(
    relevance: Sequence[Number],
    y_score: Sequence[Number],
    k: int | None = None,
) -> float:
    _check_equal_length(relevance, y_score)
    rel = _to_float_list(relevance)
    score = _to_float_list(y_score)

    if k is None:
        k = len(rel)

    if k <= 0:
        raise ValueError("k must be positive.")

    k = min(k, len(rel))

    ranked_indices = sorted(range(len(score)), key=lambda i: score[i], reverse=True)[:k]
    ideal_indices = sorted(range(len(rel)), key=lambda i: rel[i], reverse=True)[:k]

    def dcg(indices: list[int]) -> float:
        return sum(((2.0 ** rel[i]) - 1.0) / math.log2(rank + 2.0) for rank, i in enumerate(indices))

    actual = dcg(ranked_indices)
    ideal = dcg(ideal_indices)

    if ideal == 0:
        raise ValueError("NDCG is undefined when ideal DCG is zero.")

    return float(actual / ideal)


def bootstrap_confidence_interval(
    metric_fn: Callable[..., float],
    *arrays: Sequence[Number],
    n_bootstrap: int = 1000,
    confidence: float = 0.95,
    seed: int = 1,
    **metric_kwargs,
) -> dict[str, float]:
    if n_bootstrap <= 0:
        raise ValueError("n_bootstrap must be positive.")

    if not 0.0 < confidence < 1.0:
        raise ValueError("confidence must be between 0 and 1.")

    _check_equal_length(*arrays)
    n = len(arrays[0])
    rng = random.Random(seed)

    estimates: list[float] = []

    for _ in range(n_bootstrap):
        idx = [rng.randrange(n) for _ in range(n)]
        sampled = [[arr[i] for i in idx] for arr in arrays]
        try:
            estimates.append(float(metric_fn(*sampled, **metric_kwargs)))
        except ValueError:
            continue

    if not estimates:
        raise ValueError("No valid bootstrap estimates were produced.")

    estimates.sort()

    alpha = 1.0 - confidence
    lo_idx = max(0, int(math.floor((alpha / 2.0) * (len(estimates) - 1))))
    hi_idx = min(len(estimates) - 1, int(math.ceil((1.0 - alpha / 2.0) * (len(estimates) - 1))))

    point_estimate = float(metric_fn(*arrays, **metric_kwargs))

    return {
        "point_estimate": point_estimate,
        "ci_lower": float(estimates[lo_idx]),
        "ci_upper": float(estimates[hi_idx]),
        "confidence": float(confidence),
        "n_bootstrap_requested": float(n_bootstrap),
        "n_bootstrap_valid": float(len(estimates)),
    }
