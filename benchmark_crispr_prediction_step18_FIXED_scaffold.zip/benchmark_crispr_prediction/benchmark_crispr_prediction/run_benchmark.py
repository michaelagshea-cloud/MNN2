
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from benchmark_crispr_prediction.metrics import (
    auroc,
    pr_auc,
    sensitivity,
    specificity,
    f1_score,
    mcc,
    recall_at_fixed_fpr,
    pearson_r,
    spearman_rho,
    rmse,
    mae,
    top_k_recall,
    enrichment_at_k,
    ndcg,
    bootstrap_confidence_interval,
)
from benchmark_crispr_prediction.validate_inputs import validate_required_columns


def read_csv_dicts(path: str | Path) -> list[dict[str, str]]:
    path = Path(path)
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_json(path: str | Path, obj: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")


def write_metric_rows(path: str | Path, rows: list[dict[str, object]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "analysis_id",
        "dataset_id",
        "model_name",
        "metric_name",
        "metric_value",
        "ci_lower",
        "ci_upper",
        "status",
        "notes",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _float_or_nan(value: str) -> float:
    try:
        return float(value)
    except Exception:
        return math.nan


def _int_or_nan(value: str) -> int:
    try:
        return int(float(value))
    except Exception:
        raise ValueError(f"Could not parse integer label: {value!r}")


def joined_offtarget_rows(
    truth_rows: list[dict[str, str]],
    pred_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    pred_index: dict[tuple[str, str, str, str, str], dict[str, str]] = {}

    for row in pred_rows:
        key = (
            row.get("dataset_id", ""),
            row.get("guide_id", ""),
            row.get("chromosome", ""),
            row.get("position", ""),
            row.get("strand", ""),
        )
        pred_index[key] = row

    joined: list[dict[str, str]] = []

    for truth in truth_rows:
        key = (
            truth.get("dataset_id", ""),
            truth.get("guide_id", ""),
            truth.get("chromosome", ""),
            truth.get("position", ""),
            truth.get("strand", ""),
        )
        pred = pred_index.get(key)
        if pred is None:
            continue

        merged = dict(truth)
        merged.update({f"pred_{k}": v for k, v in pred.items()})
        joined.append(merged)

    return joined


def joined_ontarget_rows(
    truth_rows: list[dict[str, str]],
    pred_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    pred_index: dict[tuple[str, str], dict[str, str]] = {}

    for row in pred_rows:
        key = (
            row.get("dataset_id", ""),
            row.get("guide_id", ""),
        )
        pred_index[key] = row

    joined: list[dict[str, str]] = []

    for truth in truth_rows:
        key = (
            truth.get("dataset_id", ""),
            truth.get("guide_id", ""),
        )
        pred = pred_index.get(key)
        if pred is None:
            continue

        merged = dict(truth)
        merged.update({f"pred_{k}": v for k, v in pred.items()})
        joined.append(merged)

    return joined


def compute_offtarget_metrics(
    joined: list[dict[str, str]],
    fixed_fpr: float,
    k: int,
    n_bootstrap: int,
    seed: int,
) -> list[dict[str, object]]:
    if not joined:
        return [
            {
                "analysis_id": "offtarget_binary",
                "dataset_id": "NA",
                "model_name": "NA",
                "metric_name": "NA",
                "metric_value": "",
                "ci_lower": "",
                "ci_upper": "",
                "status": "NOT_RUN_NO_JOINED_ROWS",
                "notes": "No empirical results invented.",
            }
        ]

    y_true = [_int_or_nan(r["true_label"]) for r in joined]
    y_score = [_float_or_nan(r["pred_predicted_score"]) for r in joined]

    threshold = 0.5
    y_pred_label = [
        _int_or_nan(r["pred_predicted_label"])
        if r.get("pred_predicted_label", "") not in {"", "NA", "nan"}
        else int(score >= threshold)
        for r, score in zip(joined, y_score)
    ]

    dataset_ids = sorted(set(r.get("dataset_id", "NA") for r in joined))
    model_names = sorted(set(r.get("pred_model_name", "NA") for r in joined))
    dataset_id = ";".join(dataset_ids)
    model_name = ";".join(model_names)

    metric_calls = [
        ("AUROC", auroc, (y_true, y_score), {}),
        ("PR-AUC", pr_auc, (y_true, y_score), {}),
        ("sensitivity", sensitivity, (y_true, y_pred_label), {}),
        ("specificity", specificity, (y_true, y_pred_label), {}),
        ("F1", f1_score, (y_true, y_pred_label), {}),
        ("MCC", mcc, (y_true, y_pred_label), {}),
        ("recall_at_fixed_FPR", recall_at_fixed_fpr, (y_true, y_score), {"fixed_fpr": fixed_fpr}),
        ("top_k_recall", top_k_recall, (y_true, y_score), {"k": k}),
        ("enrichment_at_k", enrichment_at_k, (y_true, y_score), {"k": k}),
        ("NDCG", ndcg, (y_true, y_score), {"k": k}),
    ]

    rows: list[dict[str, object]] = []

    for metric_name, fn, args, kwargs in metric_calls:
        try:
            ci = bootstrap_confidence_interval(
                fn,
                *args,
                n_bootstrap=n_bootstrap,
                confidence=0.95,
                seed=seed,
                **kwargs,
            )
            rows.append(
                {
                    "analysis_id": "offtarget_binary",
                    "dataset_id": dataset_id,
                    "model_name": model_name,
                    "metric_name": metric_name,
                    "metric_value": ci["point_estimate"],
                    "ci_lower": ci["ci_lower"],
                    "ci_upper": ci["ci_upper"],
                    "status": "CALCULATED_FROM_PROVIDED_INPUTS",
                    "notes": "No benchmark performance is claimed by scaffold.",
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "analysis_id": "offtarget_binary",
                    "dataset_id": dataset_id,
                    "model_name": model_name,
                    "metric_name": metric_name,
                    "metric_value": "",
                    "ci_lower": "",
                    "ci_upper": "",
                    "status": "NOT_RUN",
                    "notes": str(exc),
                }
            )

    return rows


def compute_ontarget_metrics(
    joined: list[dict[str, str]],
    n_bootstrap: int,
    seed: int,
) -> list[dict[str, object]]:
    if not joined:
        return [
            {
                "analysis_id": "ontarget_regression",
                "dataset_id": "NA",
                "model_name": "NA",
                "metric_name": "NA",
                "metric_value": "",
                "ci_lower": "",
                "ci_upper": "",
                "status": "NOT_RUN_NO_JOINED_ROWS",
                "notes": "No empirical results invented.",
            }
        ]

    y_true = [_float_or_nan(r["true_activity"]) for r in joined]
    y_pred = [_float_or_nan(r["pred_predicted_activity"]) for r in joined]

    dataset_ids = sorted(set(r.get("dataset_id", "NA") for r in joined))
    model_names = sorted(set(r.get("pred_model_name", "NA") for r in joined))
    dataset_id = ";".join(dataset_ids)
    model_name = ";".join(model_names)

    metric_calls = [
        ("Pearson_r", pearson_r, (y_true, y_pred), {}),
        ("Spearman_rho", spearman_rho, (y_true, y_pred), {}),
        ("RMSE", rmse, (y_true, y_pred), {}),
        ("MAE", mae, (y_true, y_pred), {}),
    ]

    rows: list[dict[str, object]] = []

    for metric_name, fn, args, kwargs in metric_calls:
        try:
            ci = bootstrap_confidence_interval(
                fn,
                *args,
                n_bootstrap=n_bootstrap,
                confidence=0.95,
                seed=seed,
                **kwargs,
            )
            rows.append(
                {
                    "analysis_id": "ontarget_regression",
                    "dataset_id": dataset_id,
                    "model_name": model_name,
                    "metric_name": metric_name,
                    "metric_value": ci["point_estimate"],
                    "ci_lower": ci["ci_lower"],
                    "ci_upper": ci["ci_upper"],
                    "status": "CALCULATED_FROM_PROVIDED_INPUTS",
                    "notes": "No benchmark performance is claimed by scaffold.",
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "analysis_id": "ontarget_regression",
                    "dataset_id": dataset_id,
                    "model_name": model_name,
                    "metric_name": metric_name,
                    "metric_value": "",
                    "ci_lower": "",
                    "ci_upper": "",
                    "status": "NOT_RUN",
                    "notes": str(exc),
                }
            )

    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--offtarget", default="data/processed/offtarget_standardized.csv")
    parser.add_argument("--ontarget", default="data/processed/ontarget_standardized.csv")
    parser.add_argument("--your-predictions", default="data/predictions/your_pipeline_predictions.csv")
    parser.add_argument("--baseline-predictions", default="data/predictions/baseline_tool_predictions.csv")
    parser.add_argument("--results-dir", default="results")
    parser.add_argument("--fixed-fpr", type=float, default=0.01)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--n-bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=1)
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)

    files_to_requirements = {
        args.offtarget: "offtarget_standardized",
        args.ontarget: "ontarget_standardized",
        args.your_predictions: "prediction",
        args.baseline_predictions: "prediction",
    }

    validation = validate_required_columns(
        files_to_requirements,
        output_dir=results_dir / "validation",
    )

    if validation["status"] != "PASS":
        write_json(
            results_dir / "benchmark_status.json",
            {
                "status": "FAIL_CLOSED_REQUIRED_COLUMNS_MISSING",
                "benchmark_performance_claimed": False,
                "empirical_results_invented": False,
                "validation_report": str(results_dir / "validation/input_validation_status.json"),
            },
        )
        return 2

    offtarget_rows = read_csv_dicts(args.offtarget)
    ontarget_rows = read_csv_dicts(args.ontarget)
    your_pred_rows = read_csv_dicts(args.your_predictions)
    baseline_pred_rows = read_csv_dicts(args.baseline_predictions)

    all_metric_rows: list[dict[str, object]] = []

    for label, pred_rows in [
        ("your_pipeline", your_pred_rows),
        ("baseline_tool", baseline_pred_rows),
    ]:
        joined_ot = joined_offtarget_rows(offtarget_rows, pred_rows)
        joined_on = joined_ontarget_rows(ontarget_rows, pred_rows)

        ot_metrics = compute_offtarget_metrics(
            joined_ot,
            fixed_fpr=args.fixed_fpr,
            k=args.k,
            n_bootstrap=args.n_bootstrap,
            seed=args.seed,
        )
        on_metrics = compute_ontarget_metrics(
            joined_on,
            n_bootstrap=args.n_bootstrap,
            seed=args.seed,
        )

        for row in ot_metrics + on_metrics:
            if row["model_name"] == "NA":
                row["model_name"] = label
            all_metric_rows.append(row)

    write_metric_rows(results_dir / "metric_results.csv", all_metric_rows)

    write_json(
        results_dir / "benchmark_status.json",
        {
            "status": "COMPLETED_FROM_PROVIDED_INPUTS_ONLY",
            "benchmark_performance_claimed": False,
            "empirical_results_invented": False,
            "dataset_downloads_performed": False,
            "metric_results": str(results_dir / "metric_results.csv"),
        },
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
