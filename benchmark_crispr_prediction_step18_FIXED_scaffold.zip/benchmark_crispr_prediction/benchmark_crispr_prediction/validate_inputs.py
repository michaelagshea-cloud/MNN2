from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable


REQUIRED_COLUMNS = {
    "offtarget_standardized": {
        "dataset_id",
        "source_experiment_id",
        "guide_id",
        "guide_sequence",
        "cas_system",
        "editor_type",
        "organism",
        "reference_genome",
        "chromosome",
        "position",
        "strand",
        "candidate_site_sequence",
        "pam_sequence",
        "mismatch_count",
        "true_label",
        "split",
    },
    "ontarget_standardized": {
        "dataset_id",
        "source_experiment_id",
        "guide_id",
        "guide_sequence",
        "cas_system",
        "editor_type",
        "organism",
        "reference_genome",
        "pam_sequence",
        "true_activity",
        "split",
    },
    "prediction": {
        "dataset_id",
        "guide_id",
        "predicted_score",
        "model_name",
        "model_version",
    },
}


def read_rows(path: str | Path) -> tuple[list[str], list[dict[str, str]]]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Missing required input file: {path}")

    with path.open("r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"Input file has no header: {path}")
        rows = list(reader)

    return list(reader.fieldnames), rows


def validate_required_columns(
    files_to_requirements: dict[str, str],
    output_dir: str | Path = "results/validation",
) -> dict[str, object]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    failures: list[dict[str, object]] = []

    for file_path, requirement_key in files_to_requirements.items():
        required = REQUIRED_COLUMNS[requirement_key]

        try:
            header, rows = read_rows(file_path)
            missing = sorted(required - set(header))

            if missing:
                failures.append(
                    {
                        "file_path": file_path,
                        "requirement_key": requirement_key,
                        "status": "FAIL_CLOSED_REQUIRED_COLUMNS_MISSING",
                        "error": "required columns missing",
                        "missing_columns": missing,
                        "row_count": len(rows),
                    }
                )
                continue

            if len(rows) == 0:
                failures.append(
                    {
                        "file_path": file_path,
                        "requirement_key": requirement_key,
                        "status": "FAIL_CLOSED_EMPTY_INPUTS",
                        "error": "file has required columns but no empirical/prediction rows",
                        "missing_columns": [],
                        "row_count": 0,
                    }
                )
                continue

        except Exception as exc:
            failures.append(
                {
                    "file_path": file_path,
                    "requirement_key": requirement_key,
                    "status": "FAIL_CLOSED_FILE_ERROR",
                    "error": str(exc),
                    "missing_columns": sorted(required),
                    "row_count": "",
                }
            )

    status = "FAIL_CLOSED" if failures else "PASS"

    report = {
        "status": status,
        "failures": failures,
        "benchmark_performance_claimed": False,
        "empirical_results_invented": False,
        "empty_inputs_fail_closed": True,
    }

    (output_dir / "input_validation_status.json").write_text(
        json.dumps(report, indent=2) + "\n",
        encoding="utf-8",
    )

    with (output_dir / "input_validation_failures.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["file_path", "requirement_key", "status", "error", "missing_columns", "row_count"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for failure in failures:
            writer.writerow(
                {
                    "file_path": failure["file_path"],
                    "requirement_key": failure["requirement_key"],
                    "status": failure["status"],
                    "error": failure["error"],
                    "missing_columns": ";".join(failure["missing_columns"]),
                    "row_count": failure["row_count"],
                }
            )

    return report


def fail_closed_if_invalid(files_to_requirements: dict[str, str]) -> None:
    report = validate_required_columns(files_to_requirements)
    if report["status"] != "PASS":
        raise SystemExit("FAIL_CLOSED_INPUT_VALIDATION_FAILED")
