"""CRISPR prediction benchmarking scaffold."""
