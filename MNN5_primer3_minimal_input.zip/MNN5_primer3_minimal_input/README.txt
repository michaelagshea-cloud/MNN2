# MNN5 Primer3 Minimal Input Package

This package is intentionally small.

It does not include the full CP022975.1 reference because the three-context specificity screen was already run separately.

Use this package only for Primer3 thermodynamic screening:
- Tm
- hairpin ΔG
- homodimer ΔG
- heterodimer ΔG

Do not claim order-readiness unless the Primer3 thermodynamic screen passes and the prior specificity decisions are preserved.
