# MNN5 Phase 1 Outputs Package — NOT RUN YET

Created: 2026-05-31

This is **not** the completed Phase 1 evidence ZIP.

A completed `MNN5_Phase1_outputs.zip` can only be generated after running the Phase 1 scripts locally inside `MNN5_Phase1_reproducible_package/`.

The completed ZIP must contain:

- `logs/phase1_full_run.log`
- `reports/T01_reference_checksums.sha256`
- `reports/T01_status.csv`
- `reports/T02_gff_overlap_check.csv`
- `reports/T02_orf_boundary_decision.md`
- `reports/T03_primer_specificity_summary.csv`
- `reports/T03_in_silico_pcr_hits.csv`
- `reports/test_completion_matrix.csv`
- `MANIFEST.sha256`

## To generate the real outputs ZIP

Copy `scripts/make_MNN5_Phase1_outputs.sh` into the extracted `MNN5_Phase1_reproducible_package/` folder, or run the commands inside it from that folder.

Then upload the generated `MNN5_Phase1_outputs.zip`.
