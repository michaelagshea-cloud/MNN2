#!/usr/bin/env bash
set -euo pipefail

echo "MNN5 Phase 1 execution and output zipper"
echo "Working directory:"
pwd

echo "Environment:"
python --version
datasets --version

mkdir -p logs reports

chmod +x scripts/T01_download_reference.sh scripts/run_phase1_foundation_tests.sh

echo "Running Phase 1 foundation tests..."
bash scripts/run_phase1_foundation_tests.sh 2>&1 | tee logs/phase1_full_run.log

echo "Checking required outputs..."
required_files=(
  "reports/T01_reference_checksums.sha256"
  "reports/T01_status.csv"
  "reports/T02_gff_overlap_check.csv"
  "reports/T02_orf_boundary_decision.md"
  "reports/T03_primer_specificity_summary.csv"
  "reports/T03_in_silico_pcr_hits.csv"
  "reports/test_completion_matrix.csv"
  "MANIFEST.sha256"
)

missing=0
for f in "${required_files[@]}"; do
  if [ ! -f "$f" ]; then
    echo "MISSING: $f"
    missing=1
  else
    ls -lh "$f"
  fi
done

if [ "$missing" -ne 0 ]; then
  echo "ERROR: One or more required Phase 1 output files are missing. Not creating final evidence ZIP." >&2
  exit 1
fi

echo "Critical output: T02"
cat reports/T02_orf_boundary_decision.md

echo "Critical output: T03"
cat reports/T03_primer_specificity_summary.csv

echo "Creating MNN5_Phase1_outputs.zip..."
zip -r MNN5_Phase1_outputs.zip \
  logs/phase1_full_run.log \
  reports/T01_reference_checksums.sha256 \
  reports/T01_status.csv \
  reports/T02_gff_overlap_check.csv \
  reports/T02_orf_boundary_decision.md \
  reports/T03_primer_specificity_summary.csv \
  reports/T03_in_silico_pcr_hits.csv \
  reports/test_completion_matrix.csv \
  MANIFEST.sha256

echo "Done: MNN5_Phase1_outputs.zip"
